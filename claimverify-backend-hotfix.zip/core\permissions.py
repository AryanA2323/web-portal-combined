"""
Custom permissions for the incident management platform.
"""

from django.http import HttpRequest
from typing import Optional


def is_admin(request: HttpRequest) -> bool:
    """
    Check if the user is an caseManager.
    
    Args:
        request: The HTTP request object
        
    Returns:
        bool: True if user is authenticated and is an caseManager (including super admin)
    """
    return (
        request.user.is_authenticated and 
        hasattr(request.user, 'role') and 
        request.user.role in ['CASE_MANAGER', 'SUPER_ADMIN', 'ADMIN']
    )


def is_super_admin(request: HttpRequest) -> bool:
    """
    Check if the user is a super admin.
    
    Args:
        request: The HTTP request object
        
    Returns:
        bool: True if user is authenticated and is a super admin
    """
    return (
        request.user.is_authenticated and 
        hasattr(request.user, 'role') and 
        request.user.role == 'SUPER_ADMIN'
    )


def is_vendor(request: HttpRequest) -> bool:
    """
    Check if the user is a vendor.
    
    Args:
        request: The HTTP request object
        
    Returns:
        bool: True if user is authenticated and is a vendor
    """
    return (
        request.user.is_authenticated and 
        hasattr(request.user, 'role') and 
        request.user.role == 'VENDOR'
    )


def is_qc(request: HttpRequest) -> bool:
    """
    Check if the user is a qc.
    
    Args:
        request: The HTTP request object
        
    Returns:
        bool: True if user is authenticated and is a qc
    """
    return (
        request.user.is_authenticated and 
        hasattr(request.user, 'role') and 
        request.user.role == 'QC'
    )


def is_admin_or_qc(request: HttpRequest) -> bool:
    """
    Check if the user is an caseManager or qc.
    
    Args:
        request: The HTTP request object
        
    Returns:
        bool: True if user is authenticated and is an caseManager or qc
    """
    return is_admin(request) or is_qc(request)
