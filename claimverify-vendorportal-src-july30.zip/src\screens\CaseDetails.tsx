import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Image,
  TextInput,
  Platform,
  Linking,
  Modal,
  KeyboardAvoidingView,
} from 'react-native';
import { showToast, showDialog } from '@/components/Toast';
import * as ImagePicker from 'expo-image-picker';
import * as DocumentPicker from 'expo-document-picker';
import * as Location from 'expo-location';
import { Audio } from 'expo-av';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { theme } from '@/config/theme';
import apiService from '@/services/api';
import { useDispatch } from 'react-redux';
import { markCheckAsCompleted, updateCheckStatusInStore } from '@/store/casesSlice';
import { API_BASE_URL } from '@/config/constants';
import { QuestionnaireForm } from '@/components/QuestionnaireForm';
import { DisclaimerSection } from '@/components/DisclaimerSection';
import { clearDraftQuestionnaire } from '@/utils/draftStorage';

const PRIMARY_BLUE = theme.colors.primary;
const RECORDING_RED = '#E53935';
const SUCCESS_GREEN = '#4CAF50';
const HEADER_TOP_PADDING = 14;

const SPEECH_RECORDING_OPTIONS: Audio.RecordingOptions = {
  isMeteringEnabled: false,
  android: {
    extension: '.m4a',
    outputFormat: Audio.AndroidOutputFormat.MPEG_4,
    audioEncoder: Audio.AndroidAudioEncoder.AAC,
    sampleRate: 16000,
    numberOfChannels: 1,
    bitRate: 64000,
  },
  ios: {
    extension: '.m4a',
    outputFormat: Audio.IOSOutputFormat.MPEG4AAC,
    audioQuality: Audio.IOSAudioQuality.HIGH,
    sampleRate: 16000,
    numberOfChannels: 1,
    bitRate: 64000,
    linearPCMBitDepth: 16,
    linearPCMIsBigEndian: false,
    linearPCMIsFloat: false,
  },
  web: {
    mimeType: 'audio/webm',
    bitsPerSecond: 64000,
  },
};

const checkTypeLabels: Record<string, string> = {
  claimant: 'Claimant Check',
  insured: 'Insured Check',
  driver: 'Driver Check',
  spot: 'Spot Check',
  chargesheet: 'Chargesheet',
  rti: 'RTI Check',
  rto: 'RTO Check',
};

const checkFieldLabels: Record<string, Record<string, string>> = {
  claimant: {
    claimant_name: 'Claimant Name',
    claimant_contact: 'Contact',
    claimant_address: 'Address',
    claimant_income: 'Income',
    statement: 'Statement',
    triggers: 'Triggers',
  },
  insured: {
    insured_name: 'Insured Name',
    insured_contact: 'Contact',
    insured_address: 'Address',
    policy_number: 'Policy Number',
    policy_period: 'Policy Period',
    rc: 'RC',
    permit: 'Permit',
    statement: 'Statement',
    triggers: 'Triggers',
  },
  driver: {
    driver_name: 'Driver Name',
    driver_contact: 'Contact',
    driver_address: 'Address',
    dl: 'DL Number',
    permit: 'Permit',
    occupation: 'Occupation',
    statement: 'Statement',
    triggers: 'Triggers',
  },
  spot: {
    place_of_accident: 'Place of Accident',
    police_station: 'Police Station',
    district: 'District',
    fir_number: 'FIR Number',
    time_of_accident: 'Time of Accident',
    accident_brief: 'Accident Brief',
    triggers: 'Triggers',
  },
  chargesheet: {
    court_name: 'Court Name',
    fir_number: 'FIR Number',
    mv_act: 'MV Act',
    fir_delay_days: 'FIR Delay Days',
    bsn_section: 'BSN Section',
    ipc: 'IPC',
    statement: 'Statement',
    triggers: 'Triggers',
  },
};

interface CaseDetailsProps {
  caseId: number;
  checkType: string;
}

const getEvidencePhotoName = (photo: any): string => {
  if (typeof photo === 'string') {
    const parts = photo.split('/');
    return parts[parts.length - 1] || 'evidence.jpg';
  }
  return photo?.filename || photo?.file_name || 'evidence.jpg';
};

const getEvidencePhotoUri = (photo: any, apiHost: string): string => {
  const rawUrl =
    typeof photo === 'string'
      ? photo
      : photo?.preview_url || photo?.url || photo?.photo_url || '';

  if (!rawUrl) return '';

  if (
    rawUrl.startsWith('http://') ||
    rawUrl.startsWith('https://') ||
    rawUrl.startsWith('file:') ||
    rawUrl.startsWith('content:') ||
    rawUrl.startsWith('data:')
  ) {
    return encodeURI(rawUrl);
  }

  const normalizedPath = rawUrl.startsWith('/')
    ? rawUrl
    : rawUrl.startsWith('media/')
      ? `/${rawUrl}`
      : `/media/${rawUrl}`;

  return encodeURI(`${apiHost}${normalizedPath}`);
};

const EMPTY_OBJECT = {};

export default function CaseDetails({ caseId, checkType }: CaseDetailsProps) {
  const router = useRouter();
  const dispatch = useDispatch();
  const insets = useSafeAreaInsets();
  const normalizedCheckType = String(checkType || '').toLowerCase().replace(/_checks$/, '').replace(/ check$/, '');
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [disclaimerAccepted, setDisclaimerAccepted] = useState(false);
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [deletingPhotoName, setDeletingPhotoName] = useState<string | null>(null);
  const isCompleted = data?.check?.check_status === 'Completed' || data?.check?.check_status === 'Verified';

  const CHARGESHEET_STATUS_OPTIONS = [
    'WIP',
    'Applied for CS',
    'CS Recieved to adv',
    'Dispatched',
    'not found',
  ];

  const [selectedChargesheetStatus, setSelectedChargesheetStatus] = useState<string>('WIP');
  const [advocateRemark, setAdvocateRemark] = useState<string>('');
  const [isSavingStatus, setIsSavingStatus] = useState<boolean>(false);
  const [showStatusModal, setShowStatusModal] = useState<boolean>(false);

  useEffect(() => {
    if (data?.check?.advocate_status) {
      setSelectedChargesheetStatus(data.check.advocate_status);
    } else if (data?.check?.check_status) {
      setSelectedChargesheetStatus(data.check.check_status);
    }
    if (data?.check?.advocate_remark) {
      setAdvocateRemark(data.check.advocate_remark);
    }
  }, [data?.check?.advocate_status, data?.check?.check_status, data?.check?.advocate_remark]);

  const handleUpdateChargesheetStatus = (newStatus: string) => {
    setSelectedChargesheetStatus(newStatus);
    const isPhotoRequired = (newStatus === 'Applied for CS' || newStatus === 'Dispatched');
    if (isPhotoRequired && evidencePhotos.length === 0 && pendingPhotos.length === 0) {
      showToast({
        type: 'info',
        title: 'Photo Required',
        message: `Please upload a photo below for status '${newStatus}'.`,
      });
    }
  };

  const [pendingPhotos, setPendingPhotos] = useState<any[]>([]);
  const [pendingStatements, setPendingStatements] = useState<any[]>([]);

  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [recordingUri, setRecordingUri] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const [transcriptMr, setTranscriptMr] = useState('');
  const [editedTranslation, setEditedTranslation] = useState('');
  const [statementTitle, setStatementTitle] = useState('');
  const [isApplying, setIsApplying] = useState(false);

  const recordingRef = useRef<Audio.Recording | null>(null);
  const durationIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const questionnaireDataRef = useRef<any>({});
  const assignmentAlertShownRef = useRef(false);

  const isAssignmentLoadError = useCallback((err: any) => {
    const apiMessage = String(err?.details?.error || err?.message || '').trim();
    return (
      err?.status === 403 ||
      err?.status === 404 ||
      /not assigned|removed|access denied|permission/i.test(apiMessage)
    );
  }, []);

  const getFriendlyLoadError = useCallback((err: any) => {
    const apiMessage = String(err?.details?.error || err?.message || '').trim();

    if (isAssignmentLoadError(err)) {
      return 'This check is not currently assigned to you. It may have been removed or reassigned by the admin.';
    }

    return apiMessage || 'Failed to load check details. Please try again.';
  }, [isAssignmentLoadError]);

  const isAssignmentError = (message: string | null) =>
    !!message && /not currently assigned|removed|reassigned/i.test(message);

  const loadData = useCallback(async (showLoading = true) => {
    try {
      if (showLoading) {
        setLoading(true);
      }
      setError(null);
      const response = await apiService.getVendorCheckDetail(caseId, checkType);
      setData(response);
    } catch (err: any) {
      const friendlyError = getFriendlyLoadError(err);
      setError(friendlyError);

      if (isAssignmentLoadError(err)) {
        if (!assignmentAlertShownRef.current) {
          assignmentAlertShownRef.current = true;
          showToast({
            type: 'warning',
            title: 'Check Not Assigned',
            message: 'This case is not assigned to you or has been removed from you.',
          });
        }
      } else {
        console.error('Failed to load check detail:', err);
      }
    } finally {
      if (showLoading) {
        setLoading(false);
      }
    }
  }, [caseId, checkType, getFriendlyLoadError, isAssignmentLoadError]);

  useEffect(() => {
    assignmentAlertShownRef.current = false;
    loadData();
    return () => {
      if (recordingRef.current) {
        recordingRef.current.stopAndUnloadAsync().catch(() => { });
      }
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [loadData]);

  const requestMicrophonePermission = async (): Promise<boolean> => {
    try {
      const { status } = await Audio.requestPermissionsAsync();
      if (status !== 'granted') {
        showToast({
          type: 'error',
          title: 'Permission Required',
          message: 'Microphone permission is required to record statements. Please grant permission in your device settings.',
          duration: 4000,
        });
        return false;
      }
      return true;
    } catch (err) {
      console.error('Error requesting microphone permission:', err);
      return false;
    }
  };

  const startRecording = async () => {
    const hasPermission = await requestMicrophonePermission();
    if (!hasPermission) return;

    try {
      await Audio.setAudioModeAsync({
        allowsRecordingIOS: true,
        playsInSilentModeIOS: true,
      });

      const { recording } = await Audio.Recording.createAsync(
        SPEECH_RECORDING_OPTIONS
      );

      recordingRef.current = recording;
      setIsRecording(true);
      setRecordingDuration(0);
      setRecordingUri(null);
      setShowPreview(false);
      setTranscriptMr('');
      setEditedTranslation('');

      durationIntervalRef.current = setInterval(() => {
        setRecordingDuration((prev) => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Failed to start recording:', err);
      showToast({ type: 'error', title: 'Recording Error', message: 'Failed to start recording. Please try again.' });
    }
  };

  const stopRecording = async () => {
    if (!recordingRef.current) return;

    try {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
        durationIntervalRef.current = null;
      }

      await recordingRef.current.stopAndUnloadAsync();
      const uri = recordingRef.current.getURI();

      setIsRecording(false);
      setRecordingUri(uri);

      await Audio.setAudioModeAsync({
        allowsRecordingIOS: false,
      });
    } catch (err) {
      console.error('Failed to stop recording:', err);
      setIsRecording(false);
      showToast({ type: 'error', title: 'Recording Error', message: 'Failed to stop recording.' });
    } finally {
      recordingRef.current = null;
    }
  };

  const discardRecording = () => {
    setRecordingUri(null);
    setRecordingDuration(0);
    setShowPreview(false);
    setTranscriptMr('');
    setEditedTranslation('');
    setStatementTitle('');
  };

  const processRecording = async () => {
    if (!recordingUri) {
      showToast({ type: 'warning', title: 'No Recording', message: 'Please record a statement first.' });
      return;
    }

    setIsProcessing(true);

    try {
      const filename = `statement_${Date.now()}.m4a`;
      const audioFile = {
        uri: recordingUri,
        name: filename,
        mimeType: 'audio/m4a',
      };

      const result = await apiService.previewStatementAudio(caseId, checkType, audioFile);

      if (result.success) {
        setTranscriptMr(result.transcript_mr);
        setEditedTranslation(result.translation_en);
        setShowPreview(true);
      }
    } catch (err: any) {
      console.log('Failed to process recording:', err);
      const errorMsg = err.details?.error || err.message || 'Failed to process audio';
      showToast({ type: 'error', title: 'Processing Failed', message: errorMsg, duration: 4000 });
    } finally {
      setIsProcessing(false);
    }
  };

  const submitAllEvidence = async () => {
    if (pendingPhotos.length === 0 && pendingStatements.length === 0) return;

    setUploading(true);
    let errorCount = 0;

    try {
      if (pendingPhotos.length > 0) {
        await apiService.uploadCheckEvidence(caseId, checkType, pendingPhotos);
        setPendingPhotos([]);
      }

      for (const statement of pendingStatements) {
        await apiService.applyStatementText(caseId, checkType, statement.text, statement.transcriptMr);
      }
      setPendingStatements([]);

      await apiService.markCheckCompleted(caseId, checkType);

      dispatch(markCheckAsCompleted({ caseId, checkType }));

      showDialog({
        type: 'success',
        title: 'Evidence Submitted',
        message: 'All pending evidence submitted successfully. Check marked as completed.',
        actions: [{ text: 'Done', onPress: () => router.back() }],
      });
    } catch (err: any) {
      console.log('Submit failed:', err);
      const errorMsg = err.details?.error || err.message || 'Failed to upload evidence.';
      const isLocationError = errorMsg.toLowerCase().includes('location') || errorMsg.toLowerCase().includes('mismatch');
      showDialog({
        type: 'error',
        title: isLocationError ? 'Location Mismatch' : 'Upload Rejected',
        message: isLocationError
          ? 'The evidence photo you uploaded does not match the check location. Try uploading the photo from the correct location.'
          : errorMsg,
        actions: [{ text: 'OK' }],
      });
    } finally {
      setUploading(false);
    }
  };

  const applyStatement = async () => {
    if (!editedTranslation.trim()) {
      showToast({ type: 'warning', title: 'Empty Statement', message: 'Please enter a statement before saving.' });
      return;
    }

    const trimmedTitle = statementTitle.trim();
    const trimmedStatement = editedTranslation.trim();
    const finalStatement = trimmedTitle
      ? `${trimmedTitle} - ${trimmedStatement}`
      : trimmedStatement;

    setIsApplying(true);
    try {
      await apiService.applyStatementText(caseId, checkType, finalStatement, transcriptMr);
      showToast({
        type: 'success',
        title: 'Statement Saved',
        message: 'Statement saved to check successfully.',
      });
      discardRecording();
      await loadData(false);
    } catch (err: any) {
      console.error('Failed to save statement:', err);
      showToast({ type: 'error', title: 'Save Failed', message: err?.message || 'Failed to save statement.' });
    } finally {
      setIsApplying(false);
    }
  };

  const formatDuration = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatStatementTimestamp = (value: string): string => {
    if (!value) return '';
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return '';
    return parsed.toLocaleString();
  };

  const pickAndUpload = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      showToast({ type: 'error', title: 'Permission Denied', message: 'We need access to your photos to upload visit photos.' });
      return;
    }

    const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
    let location = null;
    if (locStatus === 'granted') {
      try {
        location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      } catch (e) {
        console.warn('Could not get location', e);
      }
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: 'images' as any,
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (result.canceled || !result.assets || result.assets.length === 0) return;

    const newPhotos = result.assets.map((asset, i) => ({
      uri: asset.uri,
      name: asset.fileName || `visit_photo_${Date.now()}_${i}.jpg`,
      lat: location?.coords?.latitude?.toString() || '',
      long: location?.coords?.longitude?.toString() || '',
    }));

    setUploading(true);
    try {
      await apiService.uploadCheckEvidence(caseId, checkType, newPhotos);
      showToast({ type: 'success', title: 'Photos Uploaded', message: 'Visit photos saved successfully.' });
      await loadData(false);
    } catch (err: any) {
      console.error('Upload visit photos error:', err);
      showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload visit photos.' });
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePhoto = (photo: any) => {
    const photoName = getEvidencePhotoName(photo);
    if (!photoName) {
      showToast({ type: 'error', title: 'Remove Failed', message: 'This photo could not be identified.' });
      return;
    }

    showDialog({
      type: 'warning',
      title: 'Remove Photo',
      message: 'Do you want to remove this evidence photo?',
      actions: [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setDeletingPhotoName(photoName);
              await apiService.deleteCheckEvidence(caseId, checkType, photoName);
              await loadData(false);
            } catch (err: any) {
              console.error('Delete photo failed:', err);
              showToast({ type: 'error', title: 'Remove Failed', message: err.message || 'Failed to remove evidence photo' });
            } finally {
              setDeletingPhotoName(null);
            }
          },
        },
      ],
    });
  };

  const takePhoto = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      showToast({ type: 'error', title: 'Permission Denied', message: 'We need camera access to take photos.' });
      return;
    }

    const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
    let location = null;
    if (locStatus === 'granted') {
      try {
        location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      } catch (e) {
        console.warn('Could not get location', e);
      }
    } else {
      showToast({ type: 'error', title: 'Location Required', message: 'Location permission is required to verify photo location.' });
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      quality: 0.8,
    });

    if (result.canceled || !result.assets || result.assets.length === 0) return;

    const newPhotos = result.assets.map((asset, i) => ({
      uri: asset.uri,
      name: asset.fileName || `camera_${Date.now()}_${i}.jpg`,
      lat: location?.coords?.latitude?.toString() || '',
      long: location?.coords?.longitude?.toString() || '',
    }));

    setUploading(true);
    try {
      await apiService.uploadCheckEvidence(caseId, checkType, newPhotos);
      showToast({ type: 'success', title: 'Photo Uploaded', message: 'Visit photo saved successfully.' });
      await loadData(false);
    } catch (err: any) {
      console.error('Upload camera photo error:', err);
      showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload visit photo.' });
    } finally {
      setUploading(false);
    }
  };

  const handleUploadDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*',
        copyToCacheDirectory: true,
      });

      if (result.canceled || !result.assets || result.assets.length === 0) return;

      const asset = result.assets[0];
      const docFile = {
        uri: asset.uri,
        name: asset.name || `document_${Date.now()}`,
        type: asset.mimeType || 'application/octet-stream',
      };

      setUploading(true);
      await apiService.uploadCheckDocument(caseId, checkType, docFile);
      showToast({ type: 'success', title: 'Document Uploaded', message: 'Document saved successfully.' });
      await loadData(false);
    } catch (err: any) {
      console.error('Document picker error:', err);
      showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload document.' });
    } finally {
      setUploading(false);
    }
  };

  const handleUploadWrittenStatementPhoto = async (asset: ImagePicker.ImagePickerAsset) => {
    const originalName = asset.fileName || `${Date.now()}.jpg`;
    // Ensure the filename always starts with written_statement_ for backend parsing
    const safeName = originalName.startsWith('written_statement_')
      ? originalName
      : `written_statement_${originalName}`;

    const docFile = {
      uri: asset.uri,
      name: safeName,
    };

    setUploading(true);
    try {
      await apiService.uploadCheckDocument(caseId, checkType, docFile);
      showToast({ type: 'success', title: 'Statement Photo Uploaded', message: 'Written statement photo saved to check documents.' });
      await loadData(false);
    } catch (err: any) {
      console.error('Statement photo upload error:', err);
      showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload statement photo.' });
    } finally {
      setUploading(false);
    }
  };

  const pickWrittenStatementGallery = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      showToast({ type: 'error', title: 'Permission Denied', message: 'Permission required to select photos.' });
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: 'images' as any,
      quality: 0.8,
    });

    if (result.canceled || !result.assets || result.assets.length === 0) return;
    await handleUploadWrittenStatementPhoto(result.assets[0]);
  };

  const takeWrittenStatementCamera = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      showToast({ type: 'error', title: 'Permission Denied', message: 'Camera permission required to take photos.' });
      return;
    }

    const result = await ImagePicker.launchCameraAsync({
      quality: 0.8,
    });

    if (result.canceled || !result.assets || result.assets.length === 0) return;
    await handleUploadWrittenStatementPhoto(result.assets[0]);
  };

  const handleDeleteStatement = (index: number) => {
    showDialog({
      type: 'warning',
      title: 'Remove Statement',
      message: `Are you sure you want to remove Statement ${index}?`,
      actions: [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setUploading(true);
              await apiService.deleteCheckStatement(caseId, checkType, index);
              showToast({ type: 'success', title: 'Statement Removed', message: 'Statement removed successfully.' });
              await loadData(false);
            } catch (err: any) {
              console.error('Delete statement error:', err);
              showToast({ type: 'error', title: 'Remove Failed', message: err?.message || 'Failed to remove statement.' });
            } finally {
              setUploading(false);
            }
          },
        },
      ],
    });
  };

  const handleDeleteDocument = (filename: string, isStatementPhoto: boolean = false) => {
    showDialog({
      type: 'warning',
      title: isStatementPhoto ? 'Remove Statement Photo' : 'Remove Document',
      message: `Are you sure you want to remove this ${isStatementPhoto ? 'written statement photo' : 'document'}?`,
      actions: [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setUploading(true);
              await apiService.deleteCheckDocument(caseId, checkType, filename);
              showToast({ type: 'success', title: 'Removed', message: 'File removed successfully.' });
              await loadData(false);
            } catch (err: any) {
              console.error('Delete document error:', err);
              showToast({ type: 'error', title: 'Remove Failed', message: err?.message || 'Failed to remove file.' });
            } finally {
              setUploading(false);
            }
          },
        },
      ],
    });
  };

  const DetailRow = ({ label, value }: { label: string; value: any }) => {
    if (value === null || value === undefined || value === '') return null;
    return (
      <View style={styles.detailRow}>
        <Text style={styles.detailLabel}>{label}</Text>
        <Text style={styles.detailValue}>{String(value)}</Text>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0F5FA8', '#0A4274']} style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <MaterialCommunityIcons name="arrow-left" size={22} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Check Details</Text>
        </LinearGradient>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={PRIMARY_BLUE} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error || !data) {
    const assignmentError = isAssignmentError(error);

    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0F5FA8', '#0A4274']} style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <MaterialCommunityIcons name="arrow-left" size={22} color="#FFFFFF" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Check Details</Text>
        </LinearGradient>
        <View style={styles.errorContainer}>
          <View style={[
            styles.errorIconWrap,
            assignmentError ? styles.assignmentErrorIconWrap : styles.genericErrorIconWrap,
          ]}>
            <MaterialCommunityIcons
              name={assignmentError ? 'clipboard-remove-outline' : 'alert-circle-outline'}
              size={34}
              color={assignmentError ? theme.colors.warning : theme.colors.error}
            />
          </View>
          <Text style={styles.errorTitle}>
            {assignmentError ? 'Check not assigned' : 'Unable to open check'}
          </Text>
          <Text style={styles.errorText}>
            {error || 'No data available'}
          </Text>
          <View style={styles.errorActions}>
            <TouchableOpacity style={styles.secondaryButton} onPress={() => router.back()}>
              <Text style={styles.secondaryButtonText}>Go Back</Text>
            </TouchableOpacity>
            {assignmentError ? (
              <TouchableOpacity style={styles.retryButton} onPress={() => router.replace('/(tabs)')}>
                <Text style={styles.retryText}>Assigned Checks</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity style={styles.retryButton} onPress={() => loadData()}>
                <Text style={styles.retryText}>Retry</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </SafeAreaView>
    );
  }

  const caseInfo = data.case || {};
  const checkInfo = data.check || {};
  const evidencePhotos = checkInfo.evidence_photos || [];
  const appliedCsPhotos = Array.isArray(checkInfo.applied_cs_photos) ? checkInfo.applied_cs_photos : (typeof checkInfo.applied_cs_photos === 'string' ? (() => { try { return JSON.parse(checkInfo.applied_cs_photos); } catch { return []; } })() : []);
  const dispatchedPhotos = Array.isArray(checkInfo.dispatched_photos) ? checkInfo.dispatched_photos : (typeof checkInfo.dispatched_photos === 'string' ? (() => { try { return JSON.parse(checkInfo.dispatched_photos); } catch { return []; } })() : []);
  const writtenStatementPhotos = checkInfo.written_statement_photos || [];
  const rawDocs = checkInfo.documents || checkInfo.vendor_documents || checkInfo.case_documents || [];
  const documents = rawDocs.filter((d: any) => {
    const filename = d.filename || d.name || '';
    return d.category !== 'statement_photo' && !filename.startsWith('written_statement_');
  });
  const statementEntries = Array.isArray(checkInfo.statement_entries) ? checkInfo.statement_entries : [];
  const combinedStatementText = statementEntries.length > 0
    ? statementEntries
        .map((e: any, idx: number) => {
          const txt = (e.translation_en || e.statement_text || '').trim();
          if (!txt) return '';
          return statementEntries.length > 1 ? `Statement ${e.index || idx + 1}:\n${txt}` : txt;
        })
        .filter(Boolean)
        .join('\n\n')
    : (checkInfo.statement || '');
  const statementCount = Number.isFinite(checkInfo.statement_count)
    ? Number(checkInfo.statement_count)
    : statementEntries.length;
  const maxStatementsPerCheck = Number.isFinite(checkInfo.max_statements_per_check)
    ? Number(checkInfo.max_statements_per_check)
    : 3;
  const canAddStatement = !isCompleted && (typeof checkInfo.can_add_statement === 'boolean'
    ? checkInfo.can_add_statement
    : statementCount < maxStatementsPerCheck);
  const nextStatementIndex = checkInfo.next_statement_index || (canAddStatement ? statementCount + 1 : null);
  const fieldLabels = checkFieldLabels[checkType] || {};

  const apiHost = API_BASE_URL.replace('/api', '');

  return (
    <KeyboardAvoidingView 
      style={{ flex: 1 }} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
    >
      <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0F5FA8', '#0A4274']}
        style={[
          styles.header,
          Platform.OS === 'android' ? { paddingTop: HEADER_TOP_PADDING + insets.top } : null,
        ]}
      >
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <MaterialCommunityIcons name="arrow-left" size={22} color="#FFFFFF" />
        </TouchableOpacity>
        <View style={styles.headerTextWrap}>
          <Text style={styles.headerTitle}>{checkTypeLabels[checkType] || checkType}</Text>
          <Text style={styles.headerSubtitle}>Claim: {caseInfo.claim_number || 'N/A'}</Text>
        </View>
        <View style={styles.headerBadge}>
          <Text style={styles.headerBadgeText}>{checkInfo.check_status || 'Pending'}</Text>
        </View>
      </LinearGradient>

      <ScrollView 
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        automaticallyAdjustKeyboardInsets={true}
      >
        {normalizedCheckType !== 'chargesheet' && checkInfo.is_reassigned && (
          <View style={[styles.section, { backgroundColor: '#fff5f5', borderColor: '#feb2b2', borderWidth: 1 }]}>
            <Text style={[styles.sectionEyebrow, { color: '#e53e3e' }]}>Attention Required</Text>
            <Text style={[styles.sectionTitle, { color: '#c53030' }]}>This check was reassigned</Text>
            <Text style={{ fontSize: 15, color: '#2d3748', marginTop: 8, lineHeight: 22 }}>
              <Text style={{ fontWeight: 'bold' }}>Admin Feedback: </Text>
              {checkInfo.admin_feedback || 'No feedback provided.'}
            </Text>
          </View>
        )}

        <View style={styles.section}>
          <Text style={styles.sectionEyebrow}>Case</Text>
          <Text style={styles.sectionTitle}>Case information</Text>
          <DetailRow label="Claim Number" value={caseInfo.claim_number} />
          <DetailRow label="Client Name" value={caseInfo.client_name} />
          <DetailRow label="Category" value={caseInfo.category} />
          <DetailRow label="Case Type" value={caseInfo.case_type} />
          <DetailRow label="Case Status" value={caseInfo.full_case_status} />
          <DetailRow label="TAT Days" value={caseInfo.tat_days} />
          <DetailRow label="Receive Date" value={caseInfo.case_receive_date} />
          <DetailRow label="Due Date" value={caseInfo.case_due_date} />
          <DetailRow label="Scope of Work" value={caseInfo.scope_of_work} />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionEyebrow}>Check</Text>
          <Text style={styles.sectionTitle}>{checkTypeLabels[checkType] || 'Check'} details</Text>
          {normalizedCheckType === 'chargesheet' ? (
            <>
              {Object.entries(fieldLabels)
                .filter(([field]) => field !== 'triggers' && field !== 'check_status')
                .map(([field, label]) => (
                  <DetailRow key={field} label={label} value={checkInfo[field]} />
                ))}
            </>
          ) : (
            <>
              <DetailRow label="Status" value={checkInfo.check_status} />
              {Object.entries(fieldLabels)
                .filter(([field]) => field !== 'triggers')
                .map(([field, label]) => (
                  <DetailRow key={field} label={label} value={checkInfo[field]} />
                ))}
            </>
          )}
        </View>

        {normalizedCheckType === 'chargesheet' && (
          <View style={[styles.section, { borderLeftWidth: 4, borderLeftColor: PRIMARY_BLUE }]}>
            <Text style={styles.sectionEyebrow}>Status Update</Text>
            <Text style={styles.sectionTitle}>Advocate Status</Text>
            <Text style={[styles.detailLabel, { marginTop: 8 }]}>Advocate Status</Text>
            <TouchableOpacity
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justify: 'space-between',
                backgroundColor: '#F8FAFC',
                borderWidth: 1.5,
                borderColor: '#0F5FA8',
                borderRadius: 10,
                paddingHorizontal: 16,
                paddingVertical: 14,
                marginTop: 6,
              }}
              onPress={() => setShowStatusModal(true)}
              disabled={isSavingStatus}
              activeOpacity={0.8}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
                <MaterialCommunityIcons name="list-status" size={20} color="#0F5FA8" />
                <Text style={{ fontSize: 16, fontWeight: '700', color: '#0F5FA8' }}>
                  {selectedChargesheetStatus || 'Select Status'}
                </Text>
              </View>
              {isSavingStatus ? (
                <ActivityIndicator size="small" color="#0F5FA8" />
              ) : (
                <MaterialCommunityIcons name="chevron-down" size={24} color="#0F5FA8" />
              )}
            </TouchableOpacity>
          </View>
        )}

        {normalizedCheckType === 'chargesheet' && selectedChargesheetStatus === 'not found' && (
          <View style={[styles.section, { marginTop: 16 }]}>
            <Text style={styles.sectionTitle}>Advocate Remark</Text>
            <TextInput
              style={{
                height: 100,
                textAlignVertical: 'top',
                marginTop: 10,
                borderWidth: 1,
                borderColor: '#CBD5E1',
                borderRadius: 8,
                padding: 12,
                backgroundColor: '#FFF',
                fontSize: 15,
                color: '#334155'
              }}
              placeholder="Enter remark (e.g. why it was not found)"
              value={advocateRemark}
              onChangeText={setAdvocateRemark}
              multiline
            />
          </View>
        )}

        {normalizedCheckType === 'chargesheet' && selectedChargesheetStatus === 'Applied for CS' && (() => {
          const photos = appliedCsPhotos;
          const category = 'applied_cs';
          const sectionTitle = 'Applied for CS - Photos';

          const handleUploadFromGallery = async () => {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== 'granted') {
              showToast({ type: 'error', title: 'Permission Denied', message: 'We need access to your photos.' });
              return;
            }
            const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
            let location = null;
            if (locStatus === 'granted') {
              try { location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }); } catch (e) {}
            }
            const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: 'images' as any, allowsMultipleSelection: true, quality: 0.8 });
            if (result.canceled || !result.assets || result.assets.length === 0) return;
            const newPhotos = result.assets.map((asset, i) => ({
              uri: asset.uri,
              name: asset.fileName || `applied_cs_${Date.now()}_${i}.jpg`,
              lat: location?.coords?.latitude?.toString() || '',
              long: location?.coords?.longitude?.toString() || '',
            }));
            setUploading(true);
            try {
              await apiService.uploadCheckEvidence(caseId, checkType, newPhotos, category);
              showToast({ type: 'success', title: 'Photo Uploaded', message: 'Photo saved successfully.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload photo.' });
            } finally {
              setUploading(false);
            }
          };

          const handleTakePhoto = async () => {
            const { status } = await ImagePicker.requestCameraPermissionsAsync();
            if (status !== 'granted') {
              showToast({ type: 'error', title: 'Permission Denied', message: 'We need camera access.' });
              return;
            }
            const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
            let location = null;
            if (locStatus === 'granted') {
              try { location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }); } catch (e) {}
            } else {
              showToast({ type: 'error', title: 'Location Required', message: 'Location permission is required.' });
              return;
            }
            const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
            if (result.canceled || !result.assets || result.assets.length === 0) return;
            const newPhotos = result.assets.map((asset, i) => ({
              uri: asset.uri,
              name: asset.fileName || `applied_cs_cam_${Date.now()}_${i}.jpg`,
              lat: location?.coords?.latitude?.toString() || '',
              long: location?.coords?.longitude?.toString() || '',
            }));
            setUploading(true);
            try {
              await apiService.uploadCheckEvidence(caseId, checkType, newPhotos, category);
              showToast({ type: 'success', title: 'Photo Uploaded', message: 'Photo saved successfully.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload photo.' });
            } finally {
              setUploading(false);
            }
          };

          const handleDelete = async (photo: any) => {
            const fname = getEvidencePhotoName(photo);
            setDeletingPhotoName(fname);
            try {
              await apiService.deleteCheckEvidence(caseId, checkType, fname, category);
              showToast({ type: 'success', title: 'Photo Deleted', message: 'Photo removed.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Delete Failed', message: err?.message || 'Failed to delete photo.' });
            } finally {
              setDeletingPhotoName(null);
            }
          };

          return (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>
                {sectionTitle} ({photos.length})
              </Text>
              {photos.length === 0 ? (
                <Text style={styles.noEvidenceText}>No photos uploaded yet</Text>
              ) : (
                <View style={styles.photosGrid}>
                  {photos.map((photo: any, idx: number) => (
                    <View key={`applied-${getEvidencePhotoName(photo)}-${idx}`} style={styles.photoCard}>
                      <View style={styles.photoImageWrapper}>
                        <Image source={{ uri: getEvidencePhotoUri(photo, apiHost) }} style={styles.photoImage} resizeMode="cover" />
                        <TouchableOpacity
                          style={[styles.removePhotoButton, deletingPhotoName === getEvidencePhotoName(photo) && styles.removePhotoButtonDisabled]}
                          onPress={() => handleDelete(photo)}
                          disabled={deletingPhotoName === getEvidencePhotoName(photo)}
                          activeOpacity={0.8}
                        >
                          {deletingPhotoName === getEvidencePhotoName(photo) ? (
                            <ActivityIndicator size="small" color="#fff" />
                          ) : (
                            <Text style={styles.removePhotoButtonText}>×</Text>
                          )}
                        </TouchableOpacity>
                      </View>
                      <Text style={styles.photoName} numberOfLines={1}>{getEvidencePhotoName(photo)}</Text>
                      <Text style={styles.photoDate}>{photo.uploaded_at ? new Date(photo.uploaded_at).toLocaleDateString() : ''}</Text>
                    </View>
                  ))}
                </View>
              )}
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
                <TouchableOpacity style={[styles.smallActionButton, { flex: 1, backgroundColor: PRIMARY_BLUE }]} onPress={handleUploadFromGallery} disabled={uploading} activeOpacity={0.8}>
                  {uploading ? <ActivityIndicator color="#fff" size="small" /> : (<><MaterialCommunityIcons name="image-outline" size={16} color="#FFFFFF" /><Text style={styles.smallActionButtonText}>From Gallery</Text></>)}
                </TouchableOpacity>
                <TouchableOpacity style={[styles.smallActionButton, { flex: 1, backgroundColor: '#2E9B62' }]} onPress={handleTakePhoto} disabled={uploading} activeOpacity={0.8}>
                  {uploading ? <ActivityIndicator color="#fff" size="small" /> : (<><MaterialCommunityIcons name="camera-outline" size={16} color="#FFFFFF" /><Text style={styles.smallActionButtonText}>Take Photo</Text></>)}
                </TouchableOpacity>
              </View>
            </View>
          );
        })()}

        {normalizedCheckType === 'chargesheet' && selectedChargesheetStatus === 'Dispatched' && (() => {
          const photos = dispatchedPhotos;
          const category = 'dispatched';
          const sectionTitle = 'Dispatched - Photos';

          const handleUploadFromGallery = async () => {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== 'granted') {
              showToast({ type: 'error', title: 'Permission Denied', message: 'We need access to your photos.' });
              return;
            }
            const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
            let location = null;
            if (locStatus === 'granted') {
              try { location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }); } catch (e) {}
            }
            const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: 'images' as any, allowsMultipleSelection: true, quality: 0.8 });
            if (result.canceled || !result.assets || result.assets.length === 0) return;
            const newPhotos = result.assets.map((asset, i) => ({
              uri: asset.uri,
              name: asset.fileName || `dispatched_${Date.now()}_${i}.jpg`,
              lat: location?.coords?.latitude?.toString() || '',
              long: location?.coords?.longitude?.toString() || '',
            }));
            setUploading(true);
            try {
              await apiService.uploadCheckEvidence(caseId, checkType, newPhotos, category);
              showToast({ type: 'success', title: 'Photo Uploaded', message: 'Photo saved successfully.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload photo.' });
            } finally {
              setUploading(false);
            }
          };

          const handleTakePhoto = async () => {
            const { status } = await ImagePicker.requestCameraPermissionsAsync();
            if (status !== 'granted') {
              showToast({ type: 'error', title: 'Permission Denied', message: 'We need camera access.' });
              return;
            }
            const { status: locStatus } = await Location.requestForegroundPermissionsAsync();
            let location = null;
            if (locStatus === 'granted') {
              try { location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High }); } catch (e) {}
            } else {
              showToast({ type: 'error', title: 'Location Required', message: 'Location permission is required.' });
              return;
            }
            const result = await ImagePicker.launchCameraAsync({ quality: 0.8 });
            if (result.canceled || !result.assets || result.assets.length === 0) return;
            const newPhotos = result.assets.map((asset, i) => ({
              uri: asset.uri,
              name: asset.fileName || `dispatched_cam_${Date.now()}_${i}.jpg`,
              lat: location?.coords?.latitude?.toString() || '',
              long: location?.coords?.longitude?.toString() || '',
            }));
            setUploading(true);
            try {
              await apiService.uploadCheckEvidence(caseId, checkType, newPhotos, category);
              showToast({ type: 'success', title: 'Photo Uploaded', message: 'Photo saved successfully.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Upload Failed', message: err?.message || 'Failed to upload photo.' });
            } finally {
              setUploading(false);
            }
          };

          const handleDelete = async (photo: any) => {
            const fname = getEvidencePhotoName(photo);
            setDeletingPhotoName(fname);
            try {
              await apiService.deleteCheckEvidence(caseId, checkType, fname, category);
              showToast({ type: 'success', title: 'Photo Deleted', message: 'Photo removed.' });
              await loadData(false);
            } catch (err: any) {
              showToast({ type: 'error', title: 'Delete Failed', message: err?.message || 'Failed to delete photo.' });
            } finally {
              setDeletingPhotoName(null);
            }
          };

          return (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>
                {sectionTitle} ({photos.length})
              </Text>
              {photos.length === 0 ? (
                <Text style={styles.noEvidenceText}>No photos uploaded yet</Text>
              ) : (
                <View style={styles.photosGrid}>
                  {photos.map((photo: any, idx: number) => (
                    <View key={`dispatched-${getEvidencePhotoName(photo)}-${idx}`} style={styles.photoCard}>
                      <View style={styles.photoImageWrapper}>
                        <Image source={{ uri: getEvidencePhotoUri(photo, apiHost) }} style={styles.photoImage} resizeMode="cover" />
                        <TouchableOpacity
                          style={[styles.removePhotoButton, deletingPhotoName === getEvidencePhotoName(photo) && styles.removePhotoButtonDisabled]}
                          onPress={() => handleDelete(photo)}
                          disabled={deletingPhotoName === getEvidencePhotoName(photo)}
                          activeOpacity={0.8}
                        >
                          {deletingPhotoName === getEvidencePhotoName(photo) ? (
                            <ActivityIndicator size="small" color="#fff" />
                          ) : (
                            <Text style={styles.removePhotoButtonText}>×</Text>
                          )}
                        </TouchableOpacity>
                      </View>
                      <Text style={styles.photoName} numberOfLines={1}>{getEvidencePhotoName(photo)}</Text>
                      <Text style={styles.photoDate}>{photo.uploaded_at ? new Date(photo.uploaded_at).toLocaleDateString() : ''}</Text>
                    </View>
                  ))}
                </View>
              )}
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
                <TouchableOpacity style={[styles.smallActionButton, { flex: 1, backgroundColor: PRIMARY_BLUE }]} onPress={handleUploadFromGallery} disabled={uploading} activeOpacity={0.8}>
                  {uploading ? <ActivityIndicator color="#fff" size="small" /> : (<><MaterialCommunityIcons name="image-outline" size={16} color="#FFFFFF" /><Text style={styles.smallActionButtonText}>From Gallery</Text></>)}
                </TouchableOpacity>
                <TouchableOpacity style={[styles.smallActionButton, { flex: 1, backgroundColor: '#2E9B62' }]} onPress={handleTakePhoto} disabled={uploading} activeOpacity={0.8}>
                  {uploading ? <ActivityIndicator color="#fff" size="small" /> : (<><MaterialCommunityIcons name="camera-outline" size={16} color="#FFFFFF" /><Text style={styles.smallActionButtonText}>Take Photo</Text></>)}
                </TouchableOpacity>
              </View>
            </View>
          );
        })()}

        {normalizedCheckType === 'chargesheet' && (
          <Modal
            visible={showStatusModal}
            transparent
            animationType="fade"
            onRequestClose={() => setShowStatusModal(false)}
          >
            <TouchableOpacity
              style={{
                flex: 1,
                backgroundColor: 'rgba(0,0,0,0.5)',
                justify: 'center',
                alignItems: 'center',
                padding: 20,
              }}
              activeOpacity={1}
              onPress={() => setShowStatusModal(false)}
            >
              <View
                style={{
                  width: '100%',
                  maxWidth: 340,
                  backgroundColor: '#FFFFFF',
                  borderRadius: 14,
                  padding: 20,
                  elevation: 5,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.25,
                  shadowRadius: 4,
                }}
              >
                <Text style={{ fontSize: 18, fontWeight: '700', color: '#0F5FA8', marginBottom: 14 }}>
                  Select Advocate Status
                </Text>
                {CHARGESHEET_STATUS_OPTIONS.map((opt) => {
                  const isSelected = selectedChargesheetStatus === opt;
                  return (
                    <TouchableOpacity
                      key={opt}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        justify: 'space-between',
                        paddingVertical: 14,
                        borderBottomWidth: 1,
                        borderBottomColor: '#F1F5F9',
                      }}
                      onPress={() => {
                        setShowStatusModal(false);
                        handleUpdateChargesheetStatus(opt);
                      }}
                    >
                      <Text style={{ fontSize: 16, fontWeight: isSelected ? '700' : '400', color: isSelected ? '#0F5FA8' : '#334155' }}>
                        {opt}
                      </Text>
                      {isSelected && <MaterialCommunityIcons name="check" size={20} color="#0F5FA8" />}
                    </TouchableOpacity>
                  );
                })}
              </View>
            </TouchableOpacity>
          </Modal>
        )}

        {normalizedCheckType === 'chargesheet' && (() => {
          const isPhotoRequired = (selectedChargesheetStatus === 'Applied for CS' || selectedChargesheetStatus === 'Dispatched');
          const statusPhotos = selectedChargesheetStatus === 'Applied for CS' ? appliedCsPhotos : dispatchedPhotos;
          const hasPhoto = statusPhotos.length > 0;
          const isSubmitDisabled = uploading || (isPhotoRequired && !hasPhoto);

          return (
            <View style={[styles.section, { marginTop: 16 }]}>
              <TouchableOpacity
                style={[
                  styles.uploadButton,
                  { backgroundColor: PRIMARY_BLUE },
                  isSubmitDisabled && { backgroundColor: '#A0AEC0', opacity: 0.6 },
                ]}
                onPress={async () => {
                  try {
                    setUploading(true);
                    if (selectedChargesheetStatus) {
                      await apiService.updateCheckStatus(caseId, checkType, selectedChargesheetStatus, advocateRemark);
                      dispatch(updateCheckStatusInStore({ caseId, status: selectedChargesheetStatus }));
                    }
                    showToast({
                      type: 'success',
                      title: 'Check Saved',
                      message: 'Chargesheet check details saved successfully.',
                    });
                    await loadData(false);
                  } catch (err: any) {
                    console.error('Failed to save chargesheet check:', err);
                    showToast({
                      type: 'error',
                      title: 'Save Failed',
                      message: err?.message || 'Failed to save chargesheet check.',
                    });
                  } finally {
                    setUploading(false);
                  }
                }}
                disabled={isSubmitDisabled}
                activeOpacity={0.8}
              >
                {uploading ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <View style={styles.uploadButtonContent}>
                    <MaterialCommunityIcons name="content-save-outline" size={20} color="#FFFFFF" />
                    <Text style={styles.uploadButtonText}>Submit</Text>
                  </View>
                )}
              </TouchableOpacity>
              {isPhotoRequired && !hasPhoto && (
                <Text style={{ fontSize: 13, color: '#E53E3E', textAlign: 'center', marginTop: 8, fontWeight: '500' }}>
                  Please upload a photo above to enable Submit for status '{selectedChargesheetStatus}'.
                </Text>
              )}
            </View>
          );
        })()}

        {normalizedCheckType !== 'chargesheet' && (
          <>
        <View style={styles.section}>
          <Text style={styles.sectionEyebrow}>Statement</Text>
          <Text style={styles.sectionTitle}>Record statement in Marathi</Text>
          <Text style={styles.sectionSubtitle}>
            Speak in Marathi. The app will translate it to English for review before saving.
          </Text>
          <View style={styles.counterPill}>
            <MaterialCommunityIcons name="microphone-outline" size={15} color={theme.colors.primary} />
            <Text style={styles.statementCounterText}>
              Stored Statements: {statementCount}/{maxStatementsPerCheck}
            </Text>
          </View>

          {statementEntries.length > 0 && (
            <View style={styles.savedStatementsList}>
              {statementEntries.map((entry: any, idx: number) => (
                <View key={`statement-entry-${idx}`} style={styles.savedStatementCard}>
                  <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Text style={styles.savedStatementTitle}>Statement {entry.index || idx + 1}</Text>
                    {!isCompleted && (
                      <TouchableOpacity
                        onPress={() => handleDeleteStatement(entry.index || idx + 1)}
                        style={{ padding: 4 }}
                        activeOpacity={0.7}
                      >
                        <MaterialCommunityIcons name="close-circle-outline" size={20} color="#E53935" />
                      </TouchableOpacity>
                    )}
                  </View>
                  <Text style={styles.savedStatementText}>{entry.translation_en || entry.statement_text || ''}</Text>
                  {!!entry.created_at && (
                    <Text style={styles.savedStatementMeta}>
                      Saved: {formatStatementTimestamp(entry.created_at)}
                    </Text>
                  )}
                </View>
              ))}
            </View>
          )}

          {writtenStatementPhotos.length > 0 && (
            <View style={{ marginTop: 14 }}>
              <Text style={{ fontSize: 13, fontWeight: '700', color: theme.colors.text, marginBottom: 8 }}>
                Written Statement Photos ({writtenStatementPhotos.length})
              </Text>
              <View style={styles.photosGrid}>
                {writtenStatementPhotos.map((photo: any, idx: number) => (
                  <View key={`statement-photo-${idx}`} style={styles.photoCard}>
                    <View style={styles.photoImageWrapper}>
                      <Image
                        source={{ uri: photo.preview_url || photo.url }}
                        style={styles.photoImage}
                        resizeMode="cover"
                      />
                      {!isCompleted && (
                        <TouchableOpacity
                          style={styles.removePhotoButton}
                          onPress={() => handleDeleteDocument(photo.filename, true)}
                          activeOpacity={0.8}
                        >
                          <Text style={styles.removePhotoButtonText}>×</Text>
                        </TouchableOpacity>
                      )}
                    </View>
                    <Text style={styles.photoName} numberOfLines={1}>
                      {photo.filename || `Photo ${idx + 1}`}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {!isCompleted && !canAddStatement && (
            <View style={styles.maxStatementBanner}>
              <Text style={styles.maxStatementBannerText}>
                Maximum {maxStatementsPerCheck} statements have been stored for this check.
              </Text>
            </View>
          )}

          {!showPreview && canAddStatement && (
            <View style={styles.recordingSection}>
              {isRecording ? (
                <View style={styles.recordingActiveInline}>
                  <View style={styles.recordingIndicatorInline}>
                    <View style={styles.recordingDot} />
                    <Text style={styles.recordingTextInline}>Rec {formatDuration(recordingDuration)}</Text>
                  </View>
                  <TouchableOpacity
                    style={styles.stopButtonCompact}
                    onPress={stopRecording}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.stopButtonTextCompact}>⏹️ Stop</Text>
                  </TouchableOpacity>
                </View>
              ) : recordingUri ? (
                <View style={styles.recordingComplete}>
                  <Text style={styles.recordingCompleteText}>
                    Recording saved ({formatDuration(recordingDuration)})
                  </Text>

                  <View style={styles.recordingActions}>
                    <TouchableOpacity
                      style={styles.reRecordButton}
                      onPress={discardRecording}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.reRecordButtonText}>🔄 Re-record</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.processButton, isProcessing && styles.disabledButton]}
                      onPress={processRecording}
                      disabled={isProcessing}
                      activeOpacity={0.8}
                    >
                      {isProcessing ? (
                        <ActivityIndicator color="#fff" size="small" />
                      ) : (
                        <Text style={styles.processButtonText}>Process Recording</Text>
                      )}
                    </TouchableOpacity>
                  </View>
                </View>
              ) : (
                <TouchableOpacity
                  style={styles.recordButtonCompact}
                  onPress={startRecording}
                  activeOpacity={0.8}
                >
                  <Text style={styles.recordButtonIconCompact}>🎤</Text>
                  <Text style={styles.recordButtonTextCompact}>
                    Start Recording
                  </Text>
                </TouchableOpacity>
              )}

              {!recordingUri && (
                <View style={styles.writtenStatementContainer}>
                  <Text style={styles.writtenStatementLabel}>
                    📄 Upload photo of written statement:
                  </Text>
                  <View style={styles.sideBySideRow}>
                    <TouchableOpacity
                      style={[styles.smallActionButton, { flex: 1, backgroundColor: PRIMARY_BLUE }]}
                      onPress={pickWrittenStatementGallery}
                      disabled={uploading}
                      activeOpacity={0.8}
                    >
                      {uploading ? (
                        <ActivityIndicator color="#fff" size="small" />
                      ) : (
                        <>
                          <MaterialCommunityIcons name="image-outline" size={16} color="#FFFFFF" />
                          <Text style={styles.smallActionButtonText}>From Gallery</Text>
                        </>
                      )}
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.smallActionButton, { flex: 1, backgroundColor: '#2E9B62' }]}
                      onPress={takeWrittenStatementCamera}
                      disabled={uploading}
                      activeOpacity={0.8}
                    >
                      {uploading ? (
                        <ActivityIndicator color="#fff" size="small" />
                      ) : (
                        <>
                          <MaterialCommunityIcons name="camera-outline" size={16} color="#FFFFFF" />
                          <Text style={styles.smallActionButtonText}>Take Photo</Text>
                        </>
                      )}
                    </TouchableOpacity>
                  </View>
                </View>
              )}
            </View>
          )}

          {showPreview && canAddStatement && (
            <View style={styles.previewSection}>
              <View style={styles.translationBox}>
                <Text style={styles.transcriptLabel}>Statement Title (who is giving the statement):</Text>
                <TextInput
                  style={styles.titleInput}
                  value={statementTitle}
                  onChangeText={setStatementTitle}
                  placeholder="e.g. Statement from Vijay Sharma (claimant)"
                  placeholderTextColor="#999"
                />
              </View>

              <View style={styles.transcriptBox}>
                <Text style={styles.transcriptLabel}>Marathi Transcript:</Text>
                <Text style={styles.marathiText}>{transcriptMr}</Text>
              </View>

              <View style={styles.translationBox}>
                <Text style={styles.transcriptLabel}>English Translation (editable):</Text>
                <TextInput
                  style={styles.translationInput}
                  value={editedTranslation}
                  onChangeText={setEditedTranslation}
                  multiline
                  textAlignVertical="top"
                  placeholder="Edit translation if needed..."
                />
              </View>

              <View style={styles.previewActions}>
                <TouchableOpacity
                  style={styles.discardButton}
                  onPress={discardRecording}
                  activeOpacity={0.8}
                >
                  <Text style={styles.discardButtonText}>Discard</Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.applyButton, isApplying && styles.disabledButton]}
                  onPress={applyStatement}
                  disabled={isApplying || isCompleted}
                  activeOpacity={0.8}
                >
                  {isApplying ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Text style={styles.applyButtonText}>
                      Save Statement {nextStatementIndex || ''}
                    </Text>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>

        {/* Visit Photos Section */}
        <View style={styles.section}>
          <Text style={styles.sectionEyebrow}>Visit Photos</Text>
          <Text style={styles.sectionTitle}>
            Visit photos ({evidencePhotos.length + pendingPhotos.length})
          </Text>

          {evidencePhotos.length === 0 && pendingPhotos.length === 0 ? (
            <Text style={styles.noEvidenceText}>No visit photos uploaded yet</Text>
          ) : (
            <View style={styles.photosGrid}>
              {evidencePhotos.map((photo: any, idx: number) => (
                <View key={`${getEvidencePhotoName(photo)}-${idx}`} style={styles.photoCard}>
                  <View style={styles.photoImageWrapper}>
                    <Image
                      source={{ uri: getEvidencePhotoUri(photo, apiHost) }}
                      style={styles.photoImage}
                      resizeMode="cover"
                      onError={(event) => {
                        console.warn('Visit photo image failed to load:', {
                          photo,
                          resolvedUri: getEvidencePhotoUri(photo, apiHost),
                          error: event.nativeEvent.error,
                        });
                      }}
                    />
                    {!isCompleted && (
                      <TouchableOpacity
                        style={[
                          styles.removePhotoButton,
                          deletingPhotoName === getEvidencePhotoName(photo) && styles.removePhotoButtonDisabled,
                        ]}
                        onPress={() => handleDeletePhoto(photo)}
                        disabled={deletingPhotoName === getEvidencePhotoName(photo)}
                        activeOpacity={0.8}
                      >
                        {deletingPhotoName === getEvidencePhotoName(photo) ? (
                          <ActivityIndicator size="small" color="#fff" />
                        ) : (
                          <Text style={styles.removePhotoButtonText}>×</Text>
                        )}
                      </TouchableOpacity>
                    )}
                  </View>
                  <Text style={styles.photoName} numberOfLines={1}>
                    {getEvidencePhotoName(photo)}
                  </Text>
                  <Text style={styles.photoDate}>
                    {new Date(photo.uploaded_at).toLocaleDateString()}
                  </Text>
                </View>
              ))}

              {pendingPhotos.map((photo: any, idx: number) => (
                <View key={`pending-${photo.name}-${idx}`} style={styles.photoCard}>
                  <View style={styles.photoImageWrapper}>
                    <Image
                      source={{ uri: photo.uri }}
                      style={styles.photoImage}
                      resizeMode="cover"
                    />
                    <TouchableOpacity
                      style={styles.removePhotoButton}
                      onPress={() => {
                        setPendingPhotos((prev) => prev.filter((p) => p !== photo));
                      }}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.removePhotoButtonText}>×</Text>
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.photoName} numberOfLines={1}>
                    {photo.name} (Pending)
                  </Text>
                  <Text style={styles.photoDate}>Just now</Text>
                </View>
              ))}
            </View>
          )}

          {!isCompleted && (
            <View style={{ marginTop: 14 }}>
              <TouchableOpacity
                style={[styles.smallActionButton, { backgroundColor: '#2E9B62' }]}
                onPress={takePhoto}
                disabled={uploading}
                activeOpacity={0.8}
              >
                <MaterialCommunityIcons name="camera-outline" size={16} color="#FFFFFF" />
                <Text style={styles.smallActionButtonText}>Take Photo</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Documents Section */}
        <View style={styles.section}>
          <Text style={styles.sectionEyebrow}>Documents</Text>
          <Text style={styles.sectionTitle}>
            Check Documents ({documents.length})
          </Text>

          {documents.length === 0 ? (
            <Text style={styles.noEvidenceText}>No documents uploaded for this check yet</Text>
          ) : (
            <View style={{ gap: 8, marginTop: 8 }}>
              {documents.map((doc: any, idx: number) => (
                <View key={idx} style={styles.docItemCard}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 }}>
                    <MaterialCommunityIcons name="file-document-outline" size={24} color={PRIMARY_BLUE} />
                    <View style={{ flex: 1 }}>
                      <Text style={styles.docNameText} numberOfLines={1}>
                        {doc.filename || `Document ${idx + 1}`}
                      </Text>
                      {!!doc.uploaded_at && (
                        <Text style={styles.docDateText}>
                          {new Date(doc.uploaded_at).toLocaleDateString()}
                        </Text>
                      )}
                    </View>
                  </View>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    {doc.preview_url || doc.url ? (
                      <TouchableOpacity
                        onPress={() => Linking.openURL(doc.preview_url || doc.url)}
                        style={styles.docViewButton}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.docViewButtonText}>View</Text>
                      </TouchableOpacity>
                    ) : null}
                    {!isCompleted && (
                      <TouchableOpacity
                        onPress={() => handleDeleteDocument(doc.filename, false)}
                        style={{ padding: 4 }}
                        activeOpacity={0.7}
                      >
                        <MaterialCommunityIcons name="close-circle-outline" size={20} color="#E53935" />
                      </TouchableOpacity>
                    )}
                  </View>
                </View>
              ))}
            </View>
          )}

          {!isCompleted && (
            <TouchableOpacity
              style={[styles.smallActionButton, { backgroundColor: '#475569', marginTop: 14 }]}
              onPress={handleUploadDocument}
              disabled={uploading}
              activeOpacity={0.8}
            >
              {uploading ? (
                <ActivityIndicator color="#fff" size="small" />
              ) : (
                <>
                  <MaterialCommunityIcons name="file-upload-outline" size={16} color="#FFFFFF" />
                  <Text style={styles.smallActionButtonText}>Upload Document / File</Text>
                </>
              )}
            </TouchableOpacity>
          )}
        </View>

        <QuestionnaireForm
          caseId={caseId}
          checkType={checkType}
          initialData={checkInfo.questionnaire || EMPTY_OBJECT}
          statementText={combinedStatementText}
          caseInfo={caseInfo}
          checkInfo={checkInfo}
          onChange={(formData) => {
            questionnaireDataRef.current = formData;
          }}
          disabled={isCompleted}
        />


        {!isCompleted && (
          <View style={[styles.section, { marginTop: 16 }]}>
            {normalizedCheckType !== 'chargesheet' && (
              <DisclaimerSection checked={disclaimerAccepted} onCheck={setDisclaimerAccepted} />
            )}
            <TouchableOpacity
              style={[styles.uploadButton, { backgroundColor: (normalizedCheckType !== 'chargesheet' && !disclaimerAccepted) || uploading ? '#A0AEC0' : '#10B981', marginTop: normalizedCheckType !== 'chargesheet' ? 16 : 0 }]}
              onPress={async () => {
                showDialog({
                  type: 'warning',
                  title: 'Submit & Complete Check',
                  message: 'Are you sure you want to mark this check as completed? Admin will be notified to review your submitted check.',
                  actions: [
                    { text: 'Cancel', style: 'cancel' },
                    {
                      text: 'Confirm Submit',
                      onPress: async () => {
                        try {
                          setUploading(true);
                          if (questionnaireDataRef.current && Object.keys(questionnaireDataRef.current).length > 0) {
                            await apiService.saveQuestionnaire(caseId, checkType, questionnaireDataRef.current);
                            await clearDraftQuestionnaire(caseId, checkType);
                          }
                          await apiService.markCheckCompleted(caseId, checkType);
                          dispatch(markCheckAsCompleted({ caseId, checkType }));
                          showToast({ type: 'success', title: 'Check Completed', message: 'Check marked as completed.' });
                          router.back();
                        } catch (err: any) {
                          console.error('Failed to complete check:', err);
                          showToast({ type: 'error', title: 'Submit Failed', message: err?.message || 'Failed to complete check.' });
                        } finally {
                          setUploading(false);
                        }
                      },
                    },
                  ],
                });
              }}
              disabled={uploading || (normalizedCheckType !== 'chargesheet' && !disclaimerAccepted)}
              activeOpacity={0.8}
            >
              {uploading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <View style={styles.uploadButtonContent}>
                  <MaterialCommunityIcons name="check-circle-outline" size={20} color="#FFFFFF" />
                  <Text style={styles.uploadButtonText}>Complete &amp; Submit Check</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>
        )}
        </>
        )}
      </ScrollView>
    </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: HEADER_TOP_PADDING,
    paddingBottom: 16,
    gap: 12,
  },
  backButton: {
    width: 42,
    height: 42,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.14)',
  },
  headerTextWrap: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#DCEEFF',
    marginTop: 4,
  },
  headerBadge: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(255,255,255,0.14)',
    alignSelf: 'flex-start',
  },
  headerBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 16,
    fontSize: 14,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 24,
  },
  errorIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
  },
  assignmentErrorIconWrap: {
    backgroundColor: theme.colors.warningSoft,
  },
  genericErrorIconWrap: {
    backgroundColor: theme.colors.errorSoft,
  },
  errorTitle: {
    fontSize: 21,
    color: theme.colors.text,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 15,
    lineHeight: 22,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    marginBottom: 20,
  },
  errorActions: {
    flexDirection: 'row',
    gap: 12,
  },
  retryButton: {
    backgroundColor: PRIMARY_BLUE,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 14,
    ...theme.shadows.card,
  },
  retryText: {
    color: '#fff',
    fontWeight: '700',
  },
  secondaryButton: {
    backgroundColor: theme.colors.surface,
    paddingHorizontal: 22,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  secondaryButtonText: {
    color: theme.colors.textSecondary,
    fontWeight: '700',
  },
  section: {
    backgroundColor: '#fff',
    borderRadius: 22,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: theme.colors.divider,
    ...theme.shadows.card,
  },
  sectionEyebrow: {
    fontSize: 12,
    fontWeight: '700',
    color: theme.colors.primary,
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '800',
    color: theme.colors.text,
    marginBottom: 10,
  },
  sectionSubtitle: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    marginBottom: 16,
    lineHeight: 20,
  },
  counterPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 999,
    backgroundColor: theme.colors.primarySoft,
    marginBottom: 12,
  },
  statementCounterText: {
    fontSize: 13,
    color: theme.colors.primary,
    fontWeight: '700',
  },
  savedStatementsList: {
    gap: 8,
    marginBottom: 14,
  },
  savedStatementCard: {
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e3e8ef',
    backgroundColor: '#f8fbff',
    padding: 10,
  },
  savedStatementTitle: {
    fontSize: 13,
    color: '#1f3b66',
    fontWeight: '700',
    marginBottom: 6,
  },
  savedStatementText: {
    fontSize: 13,
    color: '#1f2937',
    lineHeight: 19,
  },
  savedStatementMeta: {
    marginTop: 6,
    fontSize: 11,
    color: '#64748b',
  },
  maxStatementBanner: {
    borderRadius: 8,
    backgroundColor: '#fef2f2',
    borderWidth: 1,
    borderColor: '#fecaca',
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginBottom: 12,
  },
  maxStatementBannerText: {
    fontSize: 12,
    color: '#991b1b',
    fontWeight: '600',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.divider,
  },
  detailLabel: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    fontWeight: '600',
    flex: 1,
  },
  detailValue: {
    fontSize: 14,
    color: theme.colors.text,
    fontWeight: '600',
    flex: 2,
    textAlign: 'right',
  },
  // Recording styles
  recordingSection: {
    marginTop: 8,
  },
  recordButton: {
    backgroundColor: PRIMARY_BLUE,
    borderRadius: 18,
    padding: 18,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
    ...theme.shadows.card,
  },
  recordButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  recordButtonIcon: {
    fontSize: 20,
  },
  recordingActive: {
    alignItems: 'center',
    padding: 22,
    backgroundColor: '#FFF3F3',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: RECORDING_RED,
  },
  recordingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  recordingDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: RECORDING_RED,
    marginRight: 8,
  },
  recordingText: {
    fontSize: 16,
    color: RECORDING_RED,
    fontWeight: '600',
  },
  durationText: {
    fontSize: 32,
    fontWeight: '700',
    color: '#1a1a1a',
    marginBottom: 16,
    fontVariant: ['tabular-nums'],
  },
  stopButton: {
    backgroundColor: RECORDING_RED,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 28,
  },
  stopButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  recordingComplete: {
    padding: 16,
    backgroundColor: '#F0FFF0',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: SUCCESS_GREEN,
  },
  recordingCompleteText: {
    fontSize: 14,
    color: SUCCESS_GREEN,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 16,
  },
  recordingActions: {
    flexDirection: 'row',
    gap: 12,
  },
  reRecordButton: {
    flex: 1,
    backgroundColor: theme.colors.surfaceMuted,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  reRecordButtonText: {
    color: theme.colors.textSecondary,
    fontSize: 14,
    fontWeight: '700',
  },
  processButton: {
    flex: 2,
    backgroundColor: PRIMARY_BLUE,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
  },
  processButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  disabledButton: {
    opacity: 0.6,
  },
  // Preview styles
  previewSection: {
    marginTop: 8,
  },
  transcriptBox: {
    backgroundColor: '#FFF8E1',
    borderRadius: 16,
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#FFE082',
  },
  transcriptLabel: {
    fontSize: 12,
    color: '#666',
    fontWeight: '600',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  marathiText: {
    fontSize: 15,
    color: '#333',
    lineHeight: 22,
  },
  translationBox: {
    marginBottom: 16,
  },
  titleInput: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 12,
    fontSize: 14,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
    height: 44,
  },
  translationInput: {
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 12,
    fontSize: 15,
    color: theme.colors.text,
    borderWidth: 1,
    borderColor: theme.colors.border,
    minHeight: 120,
    maxHeight: 200,
    textAlignVertical: 'top',
  },
  previewActions: {
    flexDirection: 'row',
    gap: 12,
  },
  discardButton: {
    flex: 1,
    backgroundColor: theme.colors.surfaceMuted,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: theme.colors.border,
  },
  discardButtonText: {
    color: theme.colors.textSecondary,
    fontSize: 14,
    fontWeight: '700',
  },
  applyButton: {
    flex: 2,
    backgroundColor: SUCCESS_GREEN,
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  applyButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  recordButtonCompact: {
    backgroundColor: RECORDING_RED,
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    alignSelf: 'center',
  },
  recordButtonTextCompact: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
  },
  recordButtonIconCompact: {
    fontSize: 16,
  },
  recordingActiveInline: {
    backgroundColor: '#FFF3F3',
    borderRadius: 12,
    paddingVertical: 8,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 1,
    borderColor: RECORDING_RED,
  },
  recordingIndicatorInline: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  recordingTextInline: {
    fontSize: 14,
    color: RECORDING_RED,
    fontWeight: '700',
  },
  stopButtonCompact: {
    backgroundColor: RECORDING_RED,
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 14,
  },
  stopButtonTextCompact: {
    color: '#fff',
    fontSize: 13,
    fontWeight: '700',
  },
  writtenStatementContainer: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: theme.colors.divider,
  },
  writtenStatementLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.colors.textSecondary,
    marginBottom: 8,
  },
  sideBySideRow: {
    flexDirection: 'row',
    gap: 10,
  },
  smallActionButton: {
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
  },
  smallActionButtonText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
  docItemCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8FAFC',
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E2E8F0',
    justifyContent: 'space-between',
  },
  docNameText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#1E293B',
  },
  docDateText: {
    fontSize: 11,
    color: '#64748B',
    marginTop: 2,
  },
  docViewButton: {
    backgroundColor: PRIMARY_BLUE,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  docViewButtonText: {
    color: '#FFF',
    fontSize: 12,
    fontWeight: '600',
  },
  // Evidence photo styles
  noEvidenceText: {
    fontSize: 14,
    color: theme.colors.textSecondary,
    textAlign: 'center',
    paddingVertical: 24,
    backgroundColor: theme.colors.surfaceMuted,
    borderRadius: 16,
  },
  photosGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  photoCard: {
    width: '47%',
    backgroundColor: '#f9f9f9',
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: theme.colors.divider,
  },
  photoImageWrapper: {
    position: 'relative',
    backgroundColor: '#fff',
  },
  photoImage: {
    width: '100%',
    height: 120,
  },
  removePhotoButton: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(0, 0, 0, 0.65)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  removePhotoButtonDisabled: {
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
  },
  removePhotoButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: '700',
    lineHeight: 20,
    marginTop: -1,
  },
  photoName: {
    fontSize: 12,
    color: theme.colors.text,
    fontWeight: '600',
    paddingHorizontal: 10,
    paddingTop: 8,
  },
  photoDate: {
    fontSize: 11,
    color: theme.colors.textMuted,
    paddingHorizontal: 10,
    paddingBottom: 10,
  },
  uploadSection: {
    gap: 12,
    marginTop: 8,
  },
  uploadButton: {
    backgroundColor: PRIMARY_BLUE,
    borderRadius: 18,
    padding: 16,
    alignItems: 'center',
    ...theme.shadows.card,
  },
  cameraButton: {
    backgroundColor: '#2E9B62',
  },
  uploadButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  uploadButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
