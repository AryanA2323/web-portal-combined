import { createSlice, PayloadAction, createAsyncThunk } from '@reduxjs/toolkit';
import { Case } from '@/types';
import apiService from '@/services/api';

interface CasesState {
  cases: Case[];
  selectedCase: Case | null;
  isLoading: boolean;
  error: string | null;
  totalCount: number;
}

const initialState: CasesState = {
  cases: [],
  selectedCase: null,
  isLoading: false,
  error: null,
  totalCount: 0,
};

export const fetchCases = createAsyncThunk(
  'cases/fetchCases',
  async (_arg: undefined, { rejectWithValue }) => {
    try {
      const response = await apiService.getVendorAssignedChecks();
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch cases');
    }
  }
);

export const fetchCaseDetail = createAsyncThunk(
  'cases/fetchCaseDetail',
  async (caseId: number, { rejectWithValue }) => {
    try {
      const response = await apiService.getCaseDetail(caseId);
      return response;
    } catch (error: any) {
      return rejectWithValue(error.message || 'Failed to fetch case details');
    }
  }
);

const casesSlice = createSlice({
  name: 'cases',
  initialState,
  reducers: {
    clearError: (state) => {
      state.error = null;
    },
    clearSelectedCase: (state) => {
      state.selectedCase = null;
    },
    clearAllCases: (state) => {
      state.cases = [];
      state.selectedCase = null;
      state.totalCount = 0;
      state.error = null;
      state.isLoading = false;
    },
    markCheckAsCompleted: (state, action: PayloadAction<{ caseId: number; checkType: string }>) => {
      state.cases = state.cases.map(c => 
        c.case_id === action.payload.caseId && c.check_type === action.payload.checkType 
          ? { ...c, check_status: 'Completed' } 
          : c
      );
    },
    updateCheckStatusInStore: (state, action: PayloadAction<{ caseId: number; status: string }>) => {
      state.cases = state.cases.map(c => 
        c.case_id === action.payload.caseId
          ? { ...c, check_status: action.payload.status } 
          : c
      );
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCases.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCases.fulfilled, (state, action: PayloadAction<any>) => {
        state.isLoading = false;
        // Handle assigned checks response format
        if (action.payload.checks) {
          state.cases = action.payload.checks;
          state.totalCount = action.payload.statistics?.total || action.payload.checks.length;
        } else if (Array.isArray(action.payload)) {
          state.cases = action.payload;
          state.totalCount = action.payload.length;
        } else if (action.payload.cases) {
          state.cases = action.payload.cases;
          state.totalCount = action.payload.total || action.payload.cases.length;
        } else if (action.payload.results) {
          state.cases = action.payload.results;
          state.totalCount = action.payload.count || action.payload.results.length;
        } else {
          state.cases = [];
          state.totalCount = 0;
        }
        state.error = null;
      })
      .addCase(fetchCases.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
        // Do not clear existing cases on a temporary background refresh failure
      })
      .addCase(fetchCaseDetail.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchCaseDetail.fulfilled, (state, action: PayloadAction<Case>) => {
        state.isLoading = false;
        state.selectedCase = action.payload;
        state.error = null;
      })
      .addCase(fetchCaseDetail.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
        state.selectedCase = null;
      });
  },
});

export const { clearError, clearSelectedCase, clearAllCases, markCheckAsCompleted, updateCheckStatusInStore } = casesSlice.actions;
export default casesSlice.reducer;
