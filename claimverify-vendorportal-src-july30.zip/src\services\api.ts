import axios, { create, AxiosInstance, AxiosError, InternalAxiosRequestConfig } from 'axios';
import { API_BASE_URL, API_TIMEOUT, STORAGE_KEYS } from '@/config/constants';
import storage from '@/services/storage';
import { ApiError, AuthResponse, VendorNotification, VendorNotificationsResponse } from '@/types';

class ApiService {
  private api: AxiosInstance;
  private isRefreshing = false;
  private failedQueue: {
    onSuccess: (token: string) => void;
    onFailed: (error: AxiosError) => void;
  }[] = [];

  constructor() {
    this.api = create({
      baseURL: API_BASE_URL,
      timeout: API_TIMEOUT,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.api.interceptors.request.use(
      async (config: InternalAxiosRequestConfig) => {
        try {
          const token = await storage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
          if (token && token.length > 0) {
            config.headers.Authorization = `Bearer ${token}`;
          }
        } catch (error) {
          console.error('Error retrieving token:', error);
        }
        return config;
      },
      (error) => Promise.reject(error)
    );

    this.api.interceptors.response.use(
      (response) => response,
      async (error: AxiosError) => {
        const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

        const isAuthEndpoint = originalRequest.url?.includes('/auth/login') || originalRequest.url?.includes('/auth/logout');

        if (error.response?.status === 401 && !originalRequest._retry && !isAuthEndpoint) {
          originalRequest._retry = true;

          if (this.isRefreshing) {
            return new Promise((onSuccess, onFailed) => {
              this.failedQueue.push({ onSuccess, onFailed });
            })
              .then((token) => {
                originalRequest.headers.Authorization = `Bearer ${token}`;
                return this.api(originalRequest);
              })
              .catch(() => Promise.reject(error));
          }

          this.isRefreshing = true;

          try {
            const refreshToken = await storage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
            if (!refreshToken) {
              await Promise.all([
                storage.deleteItem(STORAGE_KEYS.ACCESS_TOKEN).catch(() => {}),
                storage.deleteItem(STORAGE_KEYS.REFRESH_TOKEN).catch(() => {}),
                storage.deleteItem(STORAGE_KEYS.USER_DATA).catch(() => {})
              ]);
              this.isRefreshing = false;
              this.processQueue(error, null);
              return Promise.reject(error);
            }

            const response = await axios.post(
              `${API_BASE_URL}/auth/refresh/`,
              { refresh: refreshToken },
              { timeout: API_TIMEOUT }
            );

            const { access } = response.data;
            await storage.setItem(STORAGE_KEYS.ACCESS_TOKEN, access);

            this.api.defaults.headers.common.Authorization = `Bearer ${access}`;
            originalRequest.headers.Authorization = `Bearer ${access}`;

            this.processQueue(null, access);
            return this.api(originalRequest);
          } catch (refreshError) {
            this.processQueue(refreshError as AxiosError, null);
            await Promise.all([
              storage.deleteItem(STORAGE_KEYS.ACCESS_TOKEN).catch(() => {}),
              storage.deleteItem(STORAGE_KEYS.REFRESH_TOKEN).catch(() => {}),
              storage.deleteItem(STORAGE_KEYS.USER_DATA).catch(() => {})
            ]);
            return Promise.reject(error);
          } finally {
            this.isRefreshing = false;
          }
        }

        return Promise.reject(error);
      }
    );
  }

  private processQueue(error: AxiosError | null, token: string | null) {
    this.failedQueue.forEach((prom) => {
      if (error) {
        prom.onFailed(error);
      } else if (token) {
        prom.onSuccess(token);
      }
    });
    this.failedQueue = [];
  }

  private handleError(error: AxiosError): ApiError {
    const apiError: ApiError = {
      message: error.message,
      status: error.response?.status || 0,
    };

    if (error.response?.data) {
      apiError.details = error.response.data;
    }

    return apiError;
  }

  async login(email: string, password: string): Promise<AuthResponse> {
    try {
      const response = await this.api.post<any>('/auth/login', {
        username: email,
        password,
      });

      if (response.status === 202 || response.data.requires_2fa) {
        throw {
          message: response.data.message || 'Two-factor authentication required',
          status: 202,
        };
      }

      const { token, user } = response.data;
      const accessToken = token?.token || token;

      if (!accessToken || typeof accessToken !== 'string' || accessToken.length < 10) {
        console.error('Invalid token received:', accessToken);
        throw {
          message: 'Invalid authentication token received',
          status: 401,
        };
      }

      await storage.setItem(STORAGE_KEYS.ACCESS_TOKEN, accessToken);

      const vendorUser = {
        id: user.id,
        email: user.email,
        name: `${user.first_name} ${user.last_name}`.trim() || user.username,
        phone: user.phone || '',
        company: user.company || '',
        role: user.role,
      };

      return {
        user: vendorUser,
        access: accessToken,
        refresh: null,
      };
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async logout(): Promise<void> {
    try {
      await this.api.post('/auth/logout');
    } catch {
    } finally {
      await Promise.all([
        storage.deleteItem(STORAGE_KEYS.ACCESS_TOKEN).catch(() => {}),
        storage.deleteItem(STORAGE_KEYS.REFRESH_TOKEN).catch(() => {}),
        storage.deleteItem(STORAGE_KEYS.USER_DATA).catch(() => {})
      ]);
    }
  }

  async getVendorCases(vendorId?: number): Promise<any> {
    try {
      const response = await this.api.get('/vendor-cases');
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async uploadCheckDocument(caseId: number, checkType: string, fileAsset: { uri: string; name: string }): Promise<any> {
    try {
      const formData = new FormData();
      const fileType = fileAsset.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileObj: any = {
        uri: fileAsset.uri,
        name: fileAsset.name,
        type: fileType === 'pdf' ? 'application/pdf' : `image/${fileType === 'jpg' ? 'jpeg' : fileType}`,
      };
      formData.append('file', fileObj);
      formData.append('category', 'document');

      const response = await this.api.post(
        `/cases/incident-db/${caseId}/check/${checkType}/upload-media`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 60000,
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async uploadStatementPhoto(caseId: number, checkType: string, fileAsset: { uri: string; name: string }): Promise<any> {
    try {
      const formData = new FormData();
      const fileType = fileAsset.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileObj: any = {
        uri: fileAsset.uri,
        name: fileAsset.name,
        type: `image/${fileType === 'jpg' ? 'jpeg' : fileType}`,
      };
      formData.append('file', fileObj);
      formData.append('category', 'statement');

      const response = await this.api.post(
        `/cases/incident-db/${caseId}/check/${checkType}/upload-media`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 60000,
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async deleteCheckDocument(caseId: number, checkType: string, filename: string): Promise<any> {
    try {
      const response = await this.api.delete(`/vendor-check-document/${caseId}/${checkType}`, {
        params: { filename },
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async deleteCheckStatement(caseId: number, checkType: string, index: number): Promise<any> {
    try {
      const response = await this.api.delete(`/vendor-check-statement/${caseId}/${checkType}`, {
        params: { index },
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getVendorAssignedChecks(): Promise<any> {
    try {
      const response = await this.api.get('/vendor-assigned-checks');
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getVendorCheckDetail(caseId: number, checkType: string): Promise<any> {
    try {
      const response = await this.api.get(`/vendor-check-detail/${caseId}/${checkType}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async uploadCheckEvidence(
    caseId: number,
    checkType: string,
    photos: { uri: string; name: string; lat?: string; long?: string }[],
    photoCategory?: string
  ): Promise<any> {
    try {
      const formData = new FormData();
      for (const photo of photos) {
        const fileType = photo.name.split('.').pop()?.toLowerCase() || 'jpg';
        const file: any = {
          uri: photo.uri,
          name: photo.name,
          type: `image/${fileType === 'jpg' ? 'jpeg' : fileType}`,
        };
        formData.append('photos', file);
        formData.append('latitudes', photo.lat || '');
        formData.append('longitudes', photo.long || '');
      }
      if (photoCategory) {
        formData.append('photo_category', photoCategory);
      }
      const response = await this.api.post(
        `/vendor-check-upload/${caseId}/${checkType}`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 60000,
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async deleteCheckEvidence(caseId: number, checkType: string, filename: string, photoCategory?: string): Promise<any> {
    try {
      const params: any = { filename };
      if (photoCategory) {
        params.photo_category = photoCategory;
      }
      const response = await this.api.delete(`/vendor-check-evidence/${caseId}/${checkType}`, {
        params,
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async saveQuestionnaire(caseId: number, checkType: string, questionnaire: any): Promise<any> {
    try {
      const isSameAsDriver = 
        questionnaire?.insured_cum_driver === 'true' || 
        questionnaire?.insured_cum_driver === true ||
        questionnaire?.driver_and_insured_same === 'true' || 
        questionnaire?.driver_and_insured_same === true;

      const response = await this.api.post(`/vendor-check-questionnaire/${caseId}/${checkType}`, {
        questionnaire,
        insured_cum_driver: isSameAsDriver,
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async markCheckCompleted(caseId: number, checkType: string): Promise<any> {
    try {
      const response = await this.api.post(`/vendor-check-complete/${caseId}/${checkType}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async updateCheckStatus(caseId: number, checkType: string, status: string, advocateRemark?: string): Promise<any> {
    try {
      const payload: any = { status };
      if (advocateRemark !== undefined) {
        payload.advocate_remark = advocateRemark;
      }
      const response = await this.api.post(`/vendor-check-status-update/${caseId}/${checkType}`, payload);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getCases(): Promise<any> {
    try {
      // This is for admin/super admin only
      const response = await this.api.get('/cases/');
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getCaseDetail(caseId: number): Promise<any> {
    try {
      const response = await this.api.get(`/cases/${caseId}/`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getVendorProfile(): Promise<any> {
    try {
      const response = await this.api.get('/vendors/profile');
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getVendorNotifications(): Promise<VendorNotificationsResponse> {
    try {
      const response = await this.api.get('/vendor/notifications');
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async markVendorNotificationRead(notificationId: number): Promise<VendorNotification> {
    try {
      const response = await this.api.post(`/vendor/notifications/${notificationId}/read`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async registerVendorPushToken(expoPushToken: string, platform: string, deviceName = ''): Promise<any> {
    try {
      const response = await this.api.post('/vendor/notifications/push-token', {
        expo_push_token: expoPushToken,
        platform,
        device_name: deviceName,
      });
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async uploadEvidence(
    caseId: number,
    photos: { uri: string; name: string; lat?: string; long?: string }[]
  ): Promise<any> {
    try {
      const formData = new FormData();

      for (let i = 0; i < photos.length; i++) {
        const photo = photos[i];
        const fileUri = photo.uri;
        const fileName = photo.name;
        const fileType = fileName.split('.').pop()?.toLowerCase() || 'jpg';

        const file: any = {
          uri: fileUri,
          name: fileName,
          type: `image/${fileType === 'jpg' ? 'jpeg' : fileType}`,
        };

        formData.append('photos', file);
      }

      const response = await this.api.post(`/cases/${caseId}/upload-evidence`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        timeout: 60000,
      });

      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async getEvidencePhotos(caseId: number): Promise<any> {
    try {
      const response = await this.api.get(`/cases/${caseId}/evidence-photos`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async deleteEvidencePhoto(photoId: number): Promise<any> {
    try {
      const response = await this.api.delete(`/evidence-photos/${photoId}`);
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async setTokens(accessToken: string, refreshToken: string | null): Promise<void> {
    await storage.setItem(STORAGE_KEYS.ACCESS_TOKEN, accessToken);
    if (refreshToken) {
      await storage.setItem(STORAGE_KEYS.REFRESH_TOKEN, refreshToken);
    }
  }

  async clearTokens(): Promise<void> {
    await storage.deleteItem(STORAGE_KEYS.ACCESS_TOKEN);
    await storage.deleteItem(STORAGE_KEYS.REFRESH_TOKEN);
  }

  async getAccessToken(): Promise<string | null> {
    try {
      return await storage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
    } catch (error) {
      console.error('Error retrieving access token:', error);
      return null;
    }
  }

  async previewStatementAudio(
    caseId: number,
    checkType: string,
    audioFile: { uri: string; name: string; mimeType: string }
  ): Promise<{
    success: boolean;
    audit_id: number;
    transcript_mr: string;
    translation_en: string;
    detected_language: string;
    confidence: number | null;
    provider: string;
    audio_duration_seconds: number | null;
    next_statement_index: number;
    statement_count: number;
    max_statements_per_check: number;
  }> {
    try {
      const formData = new FormData();
      const file: any = {
        uri: audioFile.uri,
        name: audioFile.name,
        type: audioFile.mimeType,
      };
      formData.append('audio', file);

      const response = await this.api.post(
        `/vendor-check-statement-audio-preview/${caseId}/${checkType}`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 120000,
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async applyStatementAudio(
    caseId: number,
    checkType: string,
    audioFile: { uri: string; name: string; mimeType: string }
  ): Promise<{
    success: boolean;
    audit_id: number;
    transcript_mr: string;
    translation_en: string;
    applied_to_column: string;
    detected_language: string;
    confidence: number | null;
    provider: string;
    audio_duration_seconds: number | null;
    statement_index: number;
    statement_count: number;
    max_statements_per_check: number;
  }> {
    try {
      const formData = new FormData();
      const file: any = {
        uri: audioFile.uri,
        name: audioFile.name,
        type: audioFile.mimeType,
      };
      formData.append('audio', file);

      const response = await this.api.post(
        `/vendor-check-statement-audio-apply/${caseId}/${checkType}`,
        formData,
        {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: 120000,
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }

  async applyStatementText(
    caseId: number,
    checkType: string,
    editedEnglishText: string,
    transcriptMr?: string
  ): Promise<{
    success: boolean;
    audit_id: number;
    applied_text: string;
    applied_to_column: string;
    statement_index: number;
    statement_count: number;
    max_statements_per_check: number;
  }> {
    try {
      const response = await this.api.post(
        `/vendor-check-statement-text-apply/${caseId}/${checkType}`,
        {
          edited_english_text: editedEnglishText,
          transcript_mr: transcriptMr || '',
        }
      );
      return response.data;
    } catch (error) {
      throw this.handleError(error as AxiosError);
    }
  }
}

export default new ApiService();
