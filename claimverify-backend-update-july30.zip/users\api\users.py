"""
User management API endpoints.
"""

import logging
from typing import List, Optional
from django.contrib.auth import get_user_model
from django.db import connection, transaction
from django.db.models import ProtectedError
from django.db.utils import DatabaseError, ProgrammingError
from ninja import Router
from ninja.errors import HttpError

from users.schemas import (
    AdminUserResponseSchema,
    UserResponseSchema,
    UserUpdateSchema,
    UserCreateSchema,
    ErrorSchema,
    MessageSchema,
)
from core.permissions import is_admin

User = get_user_model()
logger = logging.getLogger(__name__)

router = Router(tags=["User Management"])


def _table_exists(table_name):
    return table_name in connection.introspection.table_names()


def _column_exists(table_name, column_name):
    if not _table_exists(table_name):
        return False
    with connection.cursor() as cursor:
        columns = [column.name for column in connection.introspection.get_table_description(cursor, table_name)]
    return column_name in columns


def _delete_if_table_exists(table_name, user_column, user_id):
    if not _table_exists(table_name) or not _column_exists(table_name, user_column):
        return
    with connection.cursor() as cursor:
        cursor.execute(f'DELETE FROM "{table_name}" WHERE "{user_column}" = %s', [user_id])


def _null_user_fk_if_exists(table_name, user_column, user_id):
    if not _table_exists(table_name) or not _column_exists(table_name, user_column):
        return
    with connection.cursor() as cursor:
        cursor.execute(f'UPDATE "{table_name}" SET "{user_column}" = NULL WHERE "{user_column}" = %s', [user_id])


def _delete_user_without_missing_relation_cascade(user):
    """
    Delete a user without letting Django cascade into stale/missing legacy
    profile tables. Production has had role-table renames, so ORM collection can
    fail before it reaches the actual user delete.
    """
    user_id = user.id
    user_table = User._meta.db_table

    # Role profile / auth helper rows that own the user relationship.
    for table_name in (
        "users_authtoken",
        "users_emailverificationcode",
        "users_passwordresettoken",
        "users_vendor",
        "users_casemanager",
        "users_casemanagerprofile",
        "users_qc",
        "users_lawyer",
        "users_admin",
    ):
        _delete_if_table_exists(table_name, "user_id", user_id)

    # Django auth M2M tables may or may not exist on older deployments.
    for table_name in (
        f"{user_table}_groups",
        f"{user_table}_user_permissions",
        "users_customuser_groups",
        "users_customuser_user_permissions",
    ):
        _delete_if_table_exists(table_name, "customuser_id", user_id)
        _delete_if_table_exists(table_name, "user_id", user_id)

    # References that should not block deleting an account.
    for table_name, column_name in (
        ("reports", "assigned_qc_id"),
        ("reports", "created_by_id"),
        ("insurance_case", "created_by_id"),
        ("insurance_case", "vendor_id"),
    ):
        _null_user_fk_if_exists(table_name, column_name, user_id)

    with connection.cursor() as cursor:
        cursor.execute(f'DELETE FROM "{user_table}" WHERE "id" = %s', [user_id])


def sync_role_specific_profile(user):
    """Ensure role-specific profile rows exist for users created by Super Admin."""
    try:
        from users.models import CaseManager, QC, Vendor

        if user.role == 'CASE_MANAGER':
            CaseManager.objects.get_or_create(
                user=user,
                defaults={
                    'employee_id': f"ADMIN_{user.id}_{int(user.date_joined.timestamp())}",
                    'department': user.sub_role or 'General',
                    'contact_email': user.email,
                },
            )
        elif user.role == 'QC':
            QC.objects.get_or_create(
                user=user,
                defaults={
                    'bar_registration_number': f"BAR_{user.id}",
                    'contact_email': user.email,
                    'specialization': 'General Practice',
                },
            )
        elif user.role in ['VENDOR', 'ADVOCATE']:
            display_name = f"{user.first_name} {user.last_name}".strip() or user.username
            Vendor.objects.update_or_create(
                user=user,
                defaults={
                    'company_name': display_name,
                    'contact_email': user.email,
                    'is_active': user.is_active,
                },
            )
        else:
            Vendor.objects.filter(user=user).update(is_active=False)
    except Exception as exc:
        logger.error(f"Failed to sync role-specific profile for user {user.username}: {exc}", exc_info=True)


# Helper function to check super admin
def is_super_admin(user) -> bool:
    """Check if user is a super admin."""
    return (
        user.is_authenticated and
        user.role == 'SUPER_ADMIN'
    )


# =============================================================================
# User Management Endpoints
# =============================================================================

@router.get(
    "/users",
    response={200: List[AdminUserResponseSchema], 401: ErrorSchema, 403: ErrorSchema},
    summary="List All Users",
    description="Get list of all users. Super Admin only.",
)
def list_users(request):
    """
    Get list of all users.
    Only accessible by super admin users.
    """
    if not request.user.is_authenticated:
        return 401, {"error": "Not authenticated", "code": "NOT_AUTHENTICATED"}
    
    if not is_super_admin(request.user):
        return 403, {"error": "Super admin access required", "code": "SUPER_ADMIN_REQUIRED"}
    
    users = User.objects.all().order_by('-date_joined')
    return 200, [AdminUserResponseSchema.model_validate(user) for user in users]


@router.post(
    "/users",
    response={201: AdminUserResponseSchema, 400: ErrorSchema, 401: ErrorSchema, 403: ErrorSchema},
    summary="Create New User",
    description="Create a new user. Super Admin only.",
)
def create_user(request, payload: UserCreateSchema):
    """
    Create a new user account.
    Only accessible by super admin users.
    
    Payload should include:
    - username: Unique username (3-150 characters)
    - email: Valid unique email address
    - password: Password (minimum 8 characters)
    - first_name: Optional first name
    - last_name: Optional last name
    - role: User role (SUPER_ADMIN, CASE_MANAGER, VENDOR, CLIENT, QC)
    """
    if not request.user.is_authenticated:
        return 401, {"error": "Not authenticated", "code": "NOT_AUTHENTICATED"}
    
    if not is_super_admin(request.user):
        return 403, {"error": "Super admin access required", "code": "SUPER_ADMIN_REQUIRED"}
    
    # Validate role
    role_upper = payload.role.upper() if payload.role else 'CLIENT'
    valid_roles = ['SUPER_ADMIN', 'CASE_MANAGER', 'VENDOR', 'CLIENT', 'QC', 'ADVOCATE']
    if role_upper not in valid_roles:
        return 400, {"error": f"Invalid role. Must be one of: {', '.join(valid_roles)}", "code": "INVALID_ROLE"}
    
    # Check if username already exists
    if User.objects.filter(username=payload.username).exists():
        return 400, {"error": "Username already exists", "code": "USERNAME_EXISTS"}
    
    # Check if email already exists
    if User.objects.filter(email=payload.email).exists():
        return 400, {"error": "Email already registered", "code": "EMAIL_EXISTS"}
    
    try:
        sub_role = 'SUPER_ADMIN' if role_upper == 'SUPER_ADMIN' else (payload.sub_role or '')

        # Create user
        user = User.objects.create_user(
            username=payload.username,
            email=payload.email,
            password=payload.password,
            first_name=payload.first_name or '',
            last_name=payload.last_name or '',
            role=role_upper,
            sub_role=sub_role,
            is_staff=role_upper == 'SUPER_ADMIN',
            is_superuser=role_upper == 'SUPER_ADMIN',
            is_active=True,
        )
        if _column_exists(User._meta.db_table, "plain_password"):
            user.plain_password = payload.password
            user.save(update_fields=["plain_password"])
        
        logger.info(f"New user {user.username} created by caseManager {request.user.username}")
        sync_role_specific_profile(user)
        
        return 201, AdminUserResponseSchema.model_validate(user)
    except Exception as e:
        error_msg = str(e)
        logger.error(f"User creation failed: {error_msg}", exc_info=True)
        return 400, {"error": f"Failed to create user: {error_msg}", "code": "USER_CREATION_FAILED"}


@router.get(
    "/users/{user_id}",
    response={200: AdminUserResponseSchema, 401: ErrorSchema, 403: ErrorSchema, 404: ErrorSchema},
    summary="Get User Details",
    description="Get details of a specific user. Super Admin only.",
)
def get_user(request, user_id: int):
    """
    Get details of a specific user.
    Only accessible by super admin users.
    """
    if not request.user.is_authenticated:
        return 401, {"error": "Not authenticated", "code": "NOT_AUTHENTICATED"}
    
    if not is_super_admin(request.user):
        return 403, {"error": "Super admin access required", "code": "SUPER_ADMIN_REQUIRED"}
    
    try:
        user = User.objects.get(id=user_id)
        return 200, AdminUserResponseSchema.model_validate(user)
    except User.DoesNotExist:
        return 404, {"error": "User not found", "code": "USER_NOT_FOUND"}


@router.put(
    "/users/{user_id}",
    response={200: AdminUserResponseSchema, 401: ErrorSchema, 403: ErrorSchema, 404: ErrorSchema, 400: ErrorSchema},
    summary="Update User",
    description="Update user details and permissions. Super Admin only.",
)
def update_user(request, user_id: int, payload: UserUpdateSchema):
    """
    Update user details including permissions.
    Only accessible by super admin users.
    
    Payload can include:
    - first_name, last_name, email: Basic user info
    - role: User role (SUPER_ADMIN, CASE_MANAGER, VENDOR, CLIENT, QC)
    - sub_role: CaseManager sub-role (SUPER_ADMIN, CASE_HANDLER, etc.)
    - permissions: Array of allowed page paths
    - is_active: Enable/disable user account
    """
    if not request.user.is_authenticated:
        return 401, {"error": "Not authenticated", "code": "NOT_AUTHENTICATED"}
    
    if not is_super_admin(request.user):
        return 403, {"error": "Super admin access required", "code": "SUPER_ADMIN_REQUIRED"}
    
    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return 404, {"error": "User not found", "code": "USER_NOT_FOUND"}
    
    log_payload = payload.dict()
    if log_payload.get("password"):
        log_payload["password"] = "***"
    logger.info(f"Updating user {user.username} with payload: {log_payload}")
    
    # Update basic fields
    if payload.first_name is not None:
        user.first_name = payload.first_name
    if payload.last_name is not None:
        user.last_name = payload.last_name
    if payload.email is not None:
        # Check if email is already used by another user
        if User.objects.filter(email=payload.email).exclude(id=user_id).exists():
            return 400, {"error": "Email already in use", "code": "EMAIL_EXISTS"}
        user.email = payload.email
    
    # Update role and sub_role
    if payload.role is not None:
        role_upper = payload.role.upper()
        valid_roles = ['SUPER_ADMIN', 'CASE_MANAGER', 'VENDOR', 'CLIENT', 'QC', 'ADVOCATE']
        if role_upper not in valid_roles:
            return 400, {"error": f"Invalid role. Must be one of: {', '.join(valid_roles)}", "code": "INVALID_ROLE"}
        user.role = role_upper
        if role_upper == 'SUPER_ADMIN' and payload.sub_role is None:
            user.sub_role = 'SUPER_ADMIN'
            user.is_staff = True
            user.is_superuser = True
        elif role_upper != 'SUPER_ADMIN':
            if role_upper != 'CASE_MANAGER' and payload.sub_role is None:
                user.sub_role = None
            user.is_superuser = False
    
    if payload.sub_role is not None:
        if payload.sub_role and payload.sub_role != '':
            sub_role_upper = str(payload.sub_role).upper()
            valid_sub_roles = ['SUPER_ADMIN', 'CASE_HANDLER', 'REPORT_MANAGER', 'LOG_MANAGER']
            if sub_role_upper not in valid_sub_roles:
                return 400, {"error": f"Invalid sub_role. Must be one of: {', '.join(valid_sub_roles)}", "code": "INVALID_SUB_ROLE"}
            user.sub_role = sub_role_upper
        else:
            user.sub_role = None
    
    # Update permissions (stored as JSON)
    if payload.permissions is not None:
        if isinstance(payload.permissions, list):
            user.permissions = payload.permissions
        else:
            logger.warning(f"Invalid permissions format: {payload.permissions}")
            user.permissions = []
    
    # Update active status
    if payload.is_active is not None:
        user.is_active = bool(payload.is_active)

    if payload.password:
        user.set_password(payload.password)
        if _column_exists(User._meta.db_table, "plain_password"):
            user.plain_password = payload.password
    
    user.save()
    sync_role_specific_profile(user)
    logger.info(f"User {user.username} updated successfully by caseManager {request.user.username}")
    
    return 200, AdminUserResponseSchema.model_validate(user)


@router.delete(
    "/users/{user_id}",
    response={200: MessageSchema, 401: ErrorSchema, 403: ErrorSchema, 404: ErrorSchema, 400: ErrorSchema},
    summary="Delete User",
    description="Delete a user. Super Admin only.",
)
def delete_user(request, user_id: int):
    """
    Delete a user.
    Only accessible by super admin users.
    Cannot delete yourself.
    """
    if not request.user.is_authenticated:
        return 401, {"error": "Not authenticated", "code": "NOT_AUTHENTICATED"}
    
    if not is_super_admin(request.user):
        return 403, {"error": "Super admin access required", "code": "SUPER_ADMIN_REQUIRED"}
    
    if request.user.id == user_id:
        return 400, {"error": "Cannot delete yourself", "code": "CANNOT_DELETE_SELF"}
    
    try:
        user = User.objects.get(id=user_id)
        username = user.username

        if user.role == 'SUPER_ADMIN' and User.objects.filter(role='SUPER_ADMIN', is_active=True).exclude(id=user_id).count() == 0:
            return 400, {"error": "Cannot delete the last active super admin", "code": "LAST_SUPER_ADMIN"}

        try:
            with transaction.atomic():
                _delete_user_without_missing_relation_cascade(user)
        except ProtectedError as exc:
            logger.warning(f"Protected delete failed for user {username}: {exc}", exc_info=True)
            return 400, {
                "error": "This user is linked to existing records and cannot be deleted. Deactivate the account instead.",
                "code": "USER_HAS_LINKED_RECORDS",
            }
        except (ProgrammingError, DatabaseError) as exc:
            logger.error(f"Database delete failed for user {username}: {exc}", exc_info=True)
            return 400, {
                "error": "This user is linked to existing records and cannot be deleted safely. Deactivate the account instead.",
                "code": "USER_DELETE_CONSTRAINT",
            }

        logger.info(f"User {username} deleted by caseManager {request.user.username}")
        return 200, {"message": f"User {username} deleted successfully"}
    except User.DoesNotExist:
        return 404, {"error": "User not found", "code": "USER_NOT_FOUND"}
    except Exception as exc:
        logger.error(f"Failed to delete user id={user_id}: {exc}", exc_info=True)
        return 400, {"error": f"Failed to delete user: {exc}", "code": "USER_DELETE_FAILED"}
